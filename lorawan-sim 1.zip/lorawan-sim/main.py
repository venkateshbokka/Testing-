#!/usr/bin/env python3
import argparse, yaml
from sim.persist import SessionStore
from sim.semtech_udp import SemtechUDPClient
from sim.frequency import RegionPlanner, make_hopper
from sim.payloads import get_payload_profile
from sim.device import DeviceSimulator

def load_config(path): 
    with open(path) as f: 
        return yaml.safe_load(f)

def main():
    ap = argparse.ArgumentParser(description="LoRaWAN OTAA/ABP Simulator")
    ap.add_argument("-c", "--config", default="config.yaml")
    args = ap.parse_args()

    cfg = load_config(args.config)
    verbose = bool(cfg["storage"]["verbose"])

    udp = SemtechUDPClient(
        host=cfg["router"]["host"],
        port=cfg["router"]["port"],
        gateway_eui_hex=cfg["router"]["gateway_eui"],
        verbose=verbose
    )

    planner = RegionPlanner(
        region=cfg["device"]["region"],
        subband_mode=cfg["device"].get("subband_mode","SUBBAND"),
        subband=int(cfg["device"].get("subband", 1)),
        join_dr=cfg["device"]["join_datarate"],
        data_dr=cfg["device"]["data_datarate"]
    )

    hopper = make_hopper(
        strategy=cfg["uplink"]["hopping_strategy"],
        join_freqs=planner.join_freqs_mhz,
        data_freqs=planner.data_freqs_mhz,
        weights=cfg["uplink"].get("weights") or None
    )

    payload_fn = get_payload_profile(cfg["device"]["payload_profile"])
    store = SessionStore(cfg["storage"]["state_file"], verbose=verbose)

    dev = DeviceSimulator(
        udp=udp,
        planner=planner,
        hopper=hopper,
        payload=payload_fn,
        mode=(cfg["device"]["mode"] or "OTAA").upper(),
        # OTAA
        dev_eui_hex=cfg["device"]["dev_eui"],
        join_eui_hex=cfg["device"]["join_eui"],
        app_key_hex=cfg["device"]["app_key"],
        # ABP
        abp_devaddr_hex=cfg["device"]["devaddr"],
        abp_nwk_skey_hex=cfg["device"]["nwk_skey"],
        abp_app_skey_hex=cfg["device"]["app_skey"],
        adr=True,
        period_sec=float(cfg["uplink"]["period_sec"]),
        probe_timeout=float(cfg["uplink"]["confirmed_probe_timeout_sec"]),
        store=store,
        verbose=verbose
    )
    dev.run()

if __name__ == "__main__":
    main()
