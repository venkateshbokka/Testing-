import json

class SessionStore:
    def __init__(self, path: str, verbose=True):
        self.path = path; self.verbose = verbose

    def load(self):
        try:
            with open(self.path) as f:
                s = json.load(f)
            if self.verbose: print(f"[STATE] loaded DevAddr={s['devaddr']} FCntUp={s['fcnt_up']}")
            return (bytes.fromhex(s["devaddr"]),
                    bytes.fromhex(s["nwk_skey"]),
                    bytes.fromhex(s["app_skey"]),
                    int(s["fcnt_up"]))
        except Exception as e:
            if self.verbose: print("[STATE] no session:", e)
            return None

    def save(self, devaddr, nwk_skey, app_skey, fcnt_up):
        s = {
            "devaddr": devaddr.hex().upper(),
            "nwk_skey": nwk_skey.hex().upper(),
            "app_skey": app_skey.hex().upper(),
            "fcnt_up": int(fcnt_up)
        }
        with open(self.path, "w") as f: json.dump(s, f)
        if self.verbose: print("[STATE] saved:", s)
