import json, threading, time, os, base64
from datetime import datetime, timezone
from .lorawan_crypto import enc_frm, data_mic
from .lorawan_join import JoinEngine
from .semtech_udp import VER, PULL_RESP, TX_ACK

class DeviceSimulator:
    def __init__(self, udp, planner, hopper, payload,
                 mode, dev_eui_hex, join_eui_hex, app_key_hex,
                 abp_devaddr_hex, abp_nwk_skey_hex, abp_app_skey_hex,
                 adr, period_sec, probe_timeout, store, verbose=True):
        self.udp=udp; self.planner=planner; self.hopper=hopper; self.payload=payload
        self.mode=mode
        self.dev_eui_hex=dev_eui_hex; self.join_eui_hex=join_eui_hex; self.app_key_hex=app_key_hex
        self.abp_devaddr_hex=abp_devaddr_hex; self.abp_nwk_skey_hex=abp_nwk_skey_hex; self.abp_app_skey_hex=abp_app_skey_hex
        self.joiner=JoinEngine(app_key_hex)
        self.adr=adr; self.period=period_sec; self.probe_timeout=probe_timeout
        self.store=store; self.verbose=verbose

        self.joined=False
        self.devaddr=None; self.nwk_skey=None; self.app_skey=None
        self.fcnt32=0; self.last_dn_seen=0.0
        self._last_devnonce=b"\x00\x00"

    def _every(self, fn, sec):
        def loop():
            while True:
                try: fn()
                except Exception as e: print("[GW] periodic error:", e)
                time.sleep(sec)
        threading.Thread(target=loop, daemon=True).start()

    def _pull(self): self.udp.pull_data()
    def _stat(self):
        self.udp.push_data({"stat":{"time":datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S GMT")}})

    def _recv_loop(self):
        while True:
            data = self.udp.recv_raw()
            if not data or len(data)<4 or data[0]!=2: 
                continue
            t = data[3]
            if t == PULL_RESP:
                js = json.loads(data[4:].decode())
                b64 = js.get("txpk",{}).get("data")
                if not b64: continue
                raw = base64.b64decode(b64 + "===")
                self.last_dn_seen = time.monotonic()
                if not self.joined and self.mode=="OTAA":
                    parsed = self.joiner.parse_join_accept(raw, self._last_devnonce)
                    if parsed:
                        token=data[1:3]; self.udp.sock.sendto(bytes([2])+token+bytes([TX_ACK]),(self.udp.host,self.udp.port))
                        self.devaddr, self.nwk_skey, self.app_skey = parsed
                        self.fcnt32 = 0
                        self.joined = True
                        self.store.save(self.devaddr, self.nwk_skey, self.app_skey, self.fcnt32)

    def _join_loop(self):
        while not self.joined:
            frame, dn = self.joiner.build_join_request(self.dev_eui_hex, self.join_eui_hex)
            self._last_devnonce = dn
            freq = self.hopper.next_join()
            rxpk=[{
                "time": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
                "tmst": int(time.time()*1_000_000) & 0xFFFFFFFF,
                "chan": 0, "rfch": 0, "freq": round(freq,4), "stat": 1,
                "modu": "LORA", "datr": self.planner.join_datarate, "codr": "4/5",
                "rssi": -35, "lsnr": 5.0, "size": len(frame), "data": base64.b64encode(frame).decode()
            }]
            self.udp.push_data({"rxpk": rxpk})
            print(f"[JOIN] JoinReq devnonce={dn.hex()} freq={freq} DR={self.planner.join_datarate}")
            time.sleep(5)

    def _one_uplink(self, confirmed=False):
        self.fcnt32 = (self.fcnt32 + 1) & 0xFFFFFFFF
        fcnt16 = self.fcnt32 & 0xFFFF
        app_payload, fport_val, meta = self.payload()

        mhdr = b"\x80" if confirmed else b"\x40"
        fctrl = (0x80 if self.adr else 0x00).to_bytes(1,"little")
        fcnt_le = fcnt16.to_bytes(2,"little")
        fport = bytes([fport_val])

        enc = enc_frm(self.app_skey, self.devaddr, app_payload, fcnt16)
        mac = self.devaddr[::-1] + fctrl + fcnt_le + fport + enc
        mic = data_mic(self.nwk_skey, self.devaddr, mhdr+mac, fcnt16)
        frame = mhdr + mac + mic

        freq = self.hopper.next_data()
        self.udp.send_rxpk(frame, freq, self.planner.data_datarate)
        tag = "CONFIRMED probe" if confirmed else "UP"
        print(f"[UP] {tag} fcnt={self.fcnt32} freq={freq} DR={self.planner.data_datarate} meta={meta}")
        self.store.save(self.devaddr, self.nwk_skey, self.app_skey, self.fcnt32)

    def _uplink_loop(self):
        next_t = time.monotonic()
        while True:
            if not self.joined:
                time.sleep(0.2); next_t = time.monotonic(); continue
            self._one_uplink(False)
            next_t += self.period
            time.sleep(max(0, next_t - time.monotonic()))

    def run(self):
        print(f"[GW] Router={self.udp.host}:{self.udp.port}  EUI={self.udp.gweui.hex().upper()}")
        print(f"[CFG] MODE={self.mode}  REGION={self.planner.region}  SUBBAND_MODE={self.planner.subband_mode}  SUBBAND={self.planner.subband}")
        print(f"[CFG] JoinDR={self.planner.join_datarate}  DataDR={self.planner.data_datarate}")
        print(f"[CFG] JoinFreqs={self.planner.join_freqs_mhz}")
        print(f"[CFG] DataFreqs({len(self.planner.data_freqs_mhz)}): {self.planner.data_freqs_mhz[:16]}{' ...' if len(self.planner.data_freqs_mhz)>16 else ''}")

        threading.Thread(target=self._recv_loop, daemon=True).start()
        self._every(self._pull, 5)
        self._every(self._stat, 30)

        s = self.store.load()
        if s:
            self.devaddr, self.nwk_skey, self.app_skey, self.fcnt32 = s
            self.joined = True
            print("[BOOT] Session found; sending confirmed probe")
            before = self.last_dn_seen
            self._one_uplink(confirmed=True)
            t0 = time.monotonic()
            while time.monotonic() - t0 < self.probe_timeout and self.last_dn_seen == before:
                time.sleep(0.05)
            if self.last_dn_seen == before and self.mode=="OTAA":
                print("[BOOT] No downlink; rejoin OTAA")
                try: os.remove(self.store.path)
                except: pass
                self.joined = False

        if self.mode=="ABP" and not self.joined:
            self.devaddr  = bytes.fromhex(self.abp_devaddr_hex)
            self.nwk_skey = bytes.fromhex(self.abp_nwk_skey_hex)
            self.app_skey = bytes.fromhex(self.abp_app_skey_hex)
            self.fcnt32   = 0
            self.joined   = True
            self.store.save(self.devaddr, self.nwk_skey, self.app_skey, self.fcnt32)
            print(f"[ABP] DevAddr={self.abp_devaddr_hex} start sending")

        if self.mode=="OTAA" and not self.joined:
            threading.Thread(target=self._join_loop, daemon=True).start()
            while not self.joined: time.sleep(0.2)

        threading.Thread(target=self._uplink_loop, daemon=True).start()
        while True: time.sleep(60)
