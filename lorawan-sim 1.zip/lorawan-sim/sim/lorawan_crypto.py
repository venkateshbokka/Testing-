from Crypto.Cipher import AES
from Crypto.Hash import CMAC

def cmacd(key, msg):
    c = CMAC.new(key, ciphermod=AES); c.update(msg); return c.digest()

def enc_frm(app_skey, devaddr, payload, fcnt16, direction=0):
    out=bytearray(); c=AES.new(app_skey,AES.MODE_ECB); i=1; dev_le=devaddr[::-1]
    while len(out)<len(payload):
        block=(b"\x01"+b"\x00"*4+bytes([direction])+dev_le+fcnt16.to_bytes(4,"little")+b"\x00"+bytes([i]))
        s=c.encrypt(block)
        chunk = payload[(i-1)*16:i*16]
        out.extend([chunk[j]^s[j] for j in range(len(chunk))])
        i+=1
    return bytes(out)

def data_mic(nwk_skey, devaddr, mhdr_mac, fcnt16, direction=0):
    dev_le=devaddr[::-1]
    b0=(b"\x49"+b"\x00"*4+bytes([direction])+dev_le+fcnt16.to_bytes(4,"little")+b"\x00"+bytes([len(mhdr_mac)]))
    return cmacd(nwk_skey, b0+mhdr_mac)[:4]
