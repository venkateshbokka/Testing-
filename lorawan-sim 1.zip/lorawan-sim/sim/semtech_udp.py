import socket, json, secrets, base64, time
from datetime import datetime, timezone

VER=2; PUSH_DATA=0x00; PUSH_ACK=0x01; PULL_DATA=0x02; PULL_RESP=0x03; PULL_ACK=0x04; TX_ACK=0x05
def b64e(b): return base64.b64encode(b).decode()

class SemtechUDPClient:
    def __init__(self, host, port, gateway_eui_hex, verbose=True):
        self.host = host; self.port = port; self.verbose = verbose
        self.gweui = bytes.fromhex(gateway_eui_hex)
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.settimeout(2.0)

    def push_data(self, payload):
        token = secrets.token_bytes(2)
        hdr = bytes([VER]) + token + bytes([PUSH_DATA]) + self.gweui
        body = json.dumps(payload, separators=(",",":")).encode()
        self.sock.sendto(hdr + body, (self.host, self.port))
        if self.verbose and "rxpk" in payload:
            p=payload["rxpk"][0]
            print(f"[GW] PUSH_DATA -> {p['freq']} {p['datr']} len={p['size']}")

    def pull_data(self):
        token = secrets.token_bytes(2)
        self.sock.sendto(bytes([VER])+token+bytes([PULL_DATA])+self.gweui, (self.host, self.port))
        if self.verbose: print("[GW] PULL_DATA sent")

    def send_rxpk(self, frame, freq_mhz, datr):
        rxpk=[{
            "time": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
            "tmst": int(time.time()*1_000_000) & 0xFFFFFFFF,
            "chan": 0, "rfch": 0, "freq": round(freq_mhz,4), "stat": 1,
            "modu": "LORA", "datr": datr, "codr": "4/5",
            "rssi": -35, "lsnr": 5.0, "size": len(frame), "data": b64e(frame)
        }]
        self.push_data({"rxpk": rxpk})

    def recv_raw(self):
        try:
            data,_ = self.sock.recvfrom(65535)
            return data
        except socket.timeout:
            return None
