import random, struct

# Temperature-only: flags|battery|temp_x100|counter
def payload_temp():
    payload_temp._ctr = (getattr(payload_temp, "_ctr", -1) + 1) & 0xFFFF
    CfgErr=Condition=MiscErr=PrelPhase=False
    SnsErr = random.choice([True, False])
    flags = (1 if CfgErr else 0)|(2 if Condition else 0)|(4 if MiscErr else 0)|(8 if PrelPhase else 0)|(16 if SnsErr else 0)
    battery = random.randint(20, 100)
    temp_c  = round(random.uniform(0.0, 90.0), 2)
    p = bytearray()
    p += struct.pack("<B", flags)
    p += struct.pack("<B", battery)
    p += struct.pack("<h", int(round(temp_c*100)))
    p += struct.pack("<H", payload_temp._ctr)
    meta = {"battery": battery, "temperature": temp_c, "count": payload_temp._ctr,
            "sensor":"Temperature","unit":"°C"}
    return bytes(p), 10, meta

# Temperature + Pressure(0..30 bar): flags|battery|temp_x100|float32(pressure)|counter
def payload_temp_pressure():
    payload_temp_pressure._ctr = (getattr(payload_temp_pressure, "_ctr", -1) + 1) & 0xFFFF
    CfgErr=Condition=MiscErr=PrelPhase=False
    SnsErr = random.choice([True, False])
    flags = (1 if CfgErr else 0)|(2 if Condition else 0)|(4 if MiscErr else 0)|(8 if PrelPhase else 0)|(16 if SnsErr else 0)
    battery = random.randint(20, 100)
    temp_c  = round(random.uniform(0.0, 90.0), 2)
    press_b = round(random.uniform(0.0, 30.0), 2)
    p = bytearray()
    p += struct.pack("<B", flags)
    p += struct.pack("<B", battery)
    p += struct.pack("<h", int(round(temp_c*100)))
    p += struct.pack("<f", float(press_b))   # float32 LE
    p += struct.pack("<H", payload_temp_pressure._ctr)
    meta = {"battery": battery, "temperature": temp_c, "data": press_b, "count": payload_temp_pressure._ctr,
            "sensor":"Pressure","unit":"Bar"}
    return bytes(p), 10, meta

def get_payload_profile(name: str):
    n = (name or "temp").lower()
    if n in ("tpress","temp+pressure","pressure"): return payload_temp_pressure
    return payload_temp
