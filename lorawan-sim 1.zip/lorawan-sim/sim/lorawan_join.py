import secrets, base64
from Crypto.Cipher import AES
from .lorawan_crypto import cmacd

def msb_to_lsb(h): return bytes.fromhex(h)[::-1]
def b64d(s): return base64.b64decode(s + "===")

class JoinEngine:
    def __init__(self, app_key_hex: str):
        self.APP_KEY = bytes.fromhex(app_key_hex)
        self._used_dn = set()

    def next_devnonce(self):
        while True:
            x=secrets.randbits(16)
            if x not in self._used_dn:
                self._used_dn.add(x); return x.to_bytes(2,"little")

    def build_join_request(self, dev_eui_hex: str, join_eui_hex: str):
        DEV_EUI  = msb_to_lsb(dev_eui_hex)    # EUIs LSB on the wire
        JOIN_EUI = msb_to_lsb(join_eui_hex)
        dn = self.next_devnonce()
        mhdr=b"\x00"; msg=mhdr + JOIN_EUI + DEV_EUI + dn
        mic=cmacd(self.APP_KEY, msg)[:4]
        return msg+mic, dn

    def derive_session_keys(self, app_nonce, net_id, dev_nonce):
        cipher=AES.new(self.APP_KEY, AES.MODE_ECB)
        nblk=bytes([0x01])+app_nonce+net_id+dev_nonce+bytes(7)
        ablk=bytes([0x02])+app_nonce+net_id+dev_nonce+bytes(7)
        return cipher.encrypt(nblk), cipher.encrypt(ablk)

    def parse_join_accept(self, raw_down: bytes, dev_nonce: bytes):
        mtype = (raw_down[0] >> 5) & 0x07
        if mtype != 0x01: return None
        enc_payload = raw_down[1:-4]
        L = len(enc_payload)
        if L not in (16,28,32): return None
        pad = (16 - (L % 16)) % 16
        enc_padded = enc_payload + (b"\x00"*pad)
        cipher = AES.new(self.APP_KEY, AES.MODE_ECB)
        dec = b"".join(cipher.encrypt(enc_padded[i:i+16]) for i in range(0,len(enc_padded),16))
        if len(dec) < 12: return None
        app_nonce = dec[0:3]; net_id = dec[3:6]; devaddr = dec[6:10][::-1]
        nwk_skey, app_skey = self.derive_session_keys(app_nonce, net_id, dev_nonce)
        print(f"[JOIN] DevAddr={devaddr.hex().upper()}  NwkSKey={nwk_skey.hex().upper()}  AppSKey={app_skey.hex().upper()}")
        return devaddr, nwk_skey, app_skey
