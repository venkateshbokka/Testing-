import random
from itertools import cycle

class RegionPlanner:
    def __init__(self, region: str, subband_mode: str, subband: int, join_dr: str, data_dr: str):
        self.region = (region or "AS923-1").upper()
        self.subband_mode = (subband_mode or "SUBBAND").upper()
        self.subband = int(subband or 1)
        self.join_datarate = join_dr
        self.data_datarate = data_dr
        self.join_freqs_mhz, self.data_freqs_mhz = self._build()

    @staticmethod
    def _eu868():
        join = [868.1, 868.3, 868.5]
        data = [868.1,868.3,868.5, 867.1,867.3,867.5,867.7,867.9]
        return join, data

    @staticmethod
    def _in865():
        join = [865.0625, 865.4025, 865.985]
        return join, join[:]

    @staticmethod
    def _kr920():
        data = [round(922.1 + 0.2*k, 4) for k in range(0, 8)]   # 922.1..923.5
        join = [922.1, 922.3, 922.5]
        return join, data

    @staticmethod
    def _ru864():
        data = [864.1, 864.3, 864.5, 864.7, 864.9]
        join = [864.1, 864.3, 864.5]
        return join, data

    @staticmethod
    def _as923(base):
        join = [base, base+0.2, base+0.4, base+0.6]
        data = [round(base + 0.2*k, 4) for k in range(0, 16)]
        return join, data

    @staticmethod
    def _usau_915(uplink_base, subband_mode="SUBBAND", subband=1):
        ch125 = [round(uplink_base + 0.2*n, 4) for n in range(64)]  # 64×125k
        if subband_mode == "ALL":
            join = ch125[:]; data = ch125[:]
        else:
            sb = max(1, min(8, int(subband)))
            start = (sb-1)*8
            join = ch125[start:start+8]
            data = join[:]
        return join, data

    def _build(self):
        r = self.region
        if r == "EU868":   return self._eu868()
        if r == "IN865":   return self._in865()
        if r == "KR920":   return self._kr920()
        if r == "RU864":   return self._ru864()
        if r == "AS923-1": return self._as923(923.2)
        if r == "AS923-2": return self._as923(921.2)
        if r == "AS923-3": return self._as923(917.2)
        if r == "AS923-4": return self._as923(917.9)
        if r == "US915":   return self._usau_915(902.3, self.subband_mode, self.subband)
        if r == "AU915":   return self._usau_915(915.2, self.subband_mode, self.subband)
        return self._as923(923.2)

# hoppers
class Hopper:
    def next_join(self): raise NotImplementedError
    def next_data(self): raise NotImplementedError

class RandomHopper(Hopper):
    def __init__(self, join, data): self.join=join; self.data=data
    def next_join(self): return random.choice(self.join)
    def next_data(self): return random.choice(self.data)

class RoundRobinHopper(Hopper):
    def __init__(self, join, data):
        self._j = cycle(join); self._d = cycle(data)
    def next_join(self): return next(self._j)
    def next_data(self): return next(self._d)

class WeightedHopper(Hopper):
    def __init__(self, join, data, weights=None):
        self.join=join; self.data=data
        self.w = weights if (weights and len(weights)==len(data)) else [1]*len(data)
    def next_join(self): return random.choice(self.join)
    def next_data(self): return random.choices(self.data, weights=self.w, k=1)[0]

def make_hopper(strategy: str, join_freqs, data_freqs, weights=None) -> Hopper:
    s = (strategy or "random").lower()
    if s == "roundrobin": return RoundRobinHopper(join_freqs, data_freqs)
    if s == "weighted":   return WeightedHopper(join_freqs, data_freqs, weights)
    return RandomHopper(join_freqs, data_freqs)
