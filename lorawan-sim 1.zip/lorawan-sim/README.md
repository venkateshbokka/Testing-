# LoRaWAN Simulator (Semtech UDP, OTAA/ABP, multi-region)

Features:
- OTAA & ABP
- Full frequency plans (EU868, IN865, KR920, RU864, AS923-1/2/3/4, US915/AU915 subband or all 64)
- Channel hopping: random / roundrobin / weighted
- 10s cadence, resume from persistent session, auto-rejoin on stale session
- Payload profiles: `temp` (temperature only) or `tpress` (temperature + pressure 0–30 bar)

## Requirements
```bash
python3 -m pip install pycryptodome pyyaml
```

## Configure
Edit `config.yaml` (EUIs/keys/region/subband, payload profile, router host).

## Run
```bash
python3 main.py -c config.yaml
```
