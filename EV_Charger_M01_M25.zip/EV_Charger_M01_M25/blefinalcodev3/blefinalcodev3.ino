#include <Arduino.h>
#include <WiFi.h>
#include <NimBLEDevice.h>
#include <ArduinoJson.h>
#include <Preferences.h>
#include <WebSocketsServer.h>
#include <esp_system.h>
#include <esp_wifi.h>
#include <ctype.h>
#include <math.h>
#include <sys/time.h>
#include <time.h>

// =====================================================
// EV charger simulator: BLE provisioning + SoftAP WebSocket
// Implements the M01-M25 WebSocket protocol and BLE B01-B05 provisioning
// operations defined in the charger message specification.
//
// Arduino libraries:
//   - NimBLE-Arduino 2.x
//   - ArduinoJson 7.x
//   - WebSockets by Markus Sattler
//   - ESP32 Arduino core 3.x
// =====================================================

// =====================================================
// BLE configuration
// =====================================================

static const char* DEVICE_NAME = "EV_SIM_001";
static const uint32_t BLE_PASSKEY = 123456;

static const char* SERVICE_UUID =
  "12345678-1234-1234-1234-123456789000";

static const char* COMMAND_UUID =
  "12345678-1234-1234-1234-123456789001";

static const char* RESPONSE_UUID =
  "12345678-1234-1234-1234-123456789002";

// =====================================================
// SoftAP and WebSocket configuration
// =====================================================

static const char* SOFTAP_SSID = "EV_SIM_001_SETUP";
static const char* SOFTAP_PASSWORD = "EVSim123!";
static const uint16_t WEBSOCKET_PORT = 81;
static const unsigned long WIFI_TIMEOUT_MS = 20000;
static const unsigned long SYSTEM_ACTION_DELAY_MS = 750;
static const unsigned long METRICS_SAVE_INTERVAL_MS = 300000;
static const size_t MAX_SYSTEM_LOG_ENTRIES = 100;
static const size_t MAX_MSA_FAULT_HISTORY = 24;
static const size_t MAX_REFERENCE_VALUES = 16;
static const size_t MAX_REFERENCE_KEY_LENGTH = 48;
static const size_t MAX_REFERENCE_STRING_LENGTH = 160;
static const size_t MAX_REFERENCE_STORAGE_BYTES = 3072;

// =====================================================
// Device identity and simulator values
// Replace these constants/read functions with real hardware data.
// =====================================================

static const char* BDC_SERIAL_NUMBER = "BDC-2026-000123";
static const char* BDC_MODEL_NUMBER = "BDC-59GA";
static const char* BDC_GATEWAY_FW = "2.4.1";
static const char* BDC_MCU_FW = "1.9.0";
static const char* BDC_FIRST_BOOT_DATE = "2026-06-20";
static const char* BDC_MANUFACTURE_DATE = "2026-05-01";

static const char* V2H_SERIAL_NUMBER = "V2H-2026-000045";
static const char* V2H_MODEL_NUMBER = "V2H-10";
static const char* V2H_FIRMWARE_VERSION = "3.0.2";
static const char* V2H_FIRST_BOOT_DATE = "2026-06-20";
static const char* V2H_MANUFACTURE_DATE = "2026-05-02";

static const char* MSA_SERIAL_NUMBER = "MSA-2026-000077";
static const char* MSA_MODEL_NUMBER = "MSA-2";
static const char* MSA_FIRMWARE_VERSION = "1.2.0";
static const char* MSA_FIRST_BOOT_DATE = "2026-06-20T08:00:00Z";
static const char* MSA_MANUFACTURE_DATE = "2026-05-03";

// =====================================================
// BLE and WebSocket objects
// =====================================================

NimBLEServer* bleServer = nullptr;
NimBLECharacteristic* commandCharacteristic = nullptr;
NimBLECharacteristic* responseCharacteristic = nullptr;
NimBLEAdvertising* bleAdvertising = nullptr;

WebSocketsServer webSocket(WEBSOCKET_PORT);
Preferences preferences;

// =====================================================
// Runtime state
// =====================================================

bool bleClientConnected = false;
bool bleConnectionEncrypted = false;
bool responseNotificationsEnabled = false;

bool wifiConnecting = false;
bool wifiNotifyLegacyProtocol = true;
bool wifiCredentialsPersistedForAttempt = false;
String pendingSsid;
String pendingPassword;
unsigned long wifiConnectionStartTime = 0;
unsigned long wifiConnectedSinceMs = 0;
wl_status_t lastWifiStatus = WL_IDLE_STATUS;
bool softApReady = false;
bool webSocketReady = false;
uint8_t activeWebSocketClients = 0;

String configuredTimezone = "UTC";
bool backupEnabled = false;
bool bdcCommissioned = false;
bool v2hCommissioned = false;
bool msaInstalled = true;
bool v2hInstalled = true;

String bdcFirmwareStatus = "Idle";
String v2hFirmwareStatus = "Idle";
String msaFirmwareStatus = "Idle";

struct CommissioningSettings {
  int circuitBreakerValue = 0;
  String chargeThrottling = "static";
  float panelLimit = 0.0f;
  float calculatedDemandLoad = 0.0f;
  bool invertCtL1 = false;
  bool invertCtL2 = false;
  bool performCpCheckFlag = false;
};

CommissioningSettings commissioning;

struct LifetimeMetrics {
  double energyChargedKwh = 1234.5;
  double energyDischargedKwh = 678.9;
  double chargingHours = 540.0;
  double dischargingHours = 210.0;
};

LifetimeMetrics lifetimeMetrics;
unsigned long lastMetricsUpdateMs = 0;
unsigned long lastMetricsSaveMs = 0;

enum class PendingSystemAction {
  None,
  RemoteReboot,
  EraseCustomerData,
  FactoryReset
};

PendingSystemAction pendingSystemAction = PendingSystemAction::None;
unsigned long pendingSystemActionAtMs = 0;

struct ChargeEventRecord {
  const char* start;
  const char* end;
  float energyKWh;
};

static const ChargeEventRecord CHARGE_EVENTS[] = {
  {"2026-06-23T22:00:00Z", "2026-06-24T02:00:00Z", 32.5f}
};

struct BackupEventRecord {
  const char* start;
  const char* end;
  float durationMinutes;
  float peakPowerKw;
  float energyKwh;
};

static const BackupEventRecord BACKUP_EVENTS[] = {
  {"2026-06-24T14:00:00Z", "2026-06-24T14:45:00Z", 45.0f, 6.2f, 3.8f},
  {"2026-06-21T18:00:00Z", "2026-06-21T18:45:00Z", 45.0f, 5.8f, 3.5f},
  {"2026-06-18T03:10:00Z", "2026-06-18T04:40:00Z", 90.0f, 7.1f, 8.4f}
};

static const size_t MAX_FAULT_RECORDS = 12;

struct FaultRecord {
  String faultId;
  String time;
  String code;
  String description;
  String status;
};

FaultRecord faultRecords[MAX_FAULT_RECORDS];
size_t faultRecordCount = 0;

struct SystemLogEntry {
  String time;
  String message;
};

SystemLogEntry systemLogEntries[MAX_SYSTEM_LOG_ENTRIES];
size_t systemLogEntryCount = 0;

struct MsaFaultHistoryEntry {
  String faultCode;
  String faultTime;
  String state;
};

MsaFaultHistoryEntry msaFaultHistory[MAX_MSA_FAULT_HISTORY];
size_t msaFaultHistoryCount = 0;
String activeMsaFaultCode;
String activeMsaFaultTime;

struct ReferenceValueRecord {
  String key;
  String type;
  String stringValue;
  bool booleanValue = false;
  int64_t integerValue = 0;
  double numberValue = 0.0;
};

ReferenceValueRecord referenceValues[MAX_REFERENCE_VALUES];
size_t referenceValueCount = 0;

// =====================================================
// Utility functions
// =====================================================

String makeUuid() {
  uint8_t bytes[16];

  for (size_t i = 0; i < sizeof(bytes); i += 4) {
    uint32_t randomValue = esp_random();
    bytes[i] = static_cast<uint8_t>(randomValue >> 24);
    bytes[i + 1] = static_cast<uint8_t>(randomValue >> 16);
    bytes[i + 2] = static_cast<uint8_t>(randomValue >> 8);
    bytes[i + 3] = static_cast<uint8_t>(randomValue);
  }

  bytes[6] = (bytes[6] & 0x0F) | 0x40;
  bytes[8] = (bytes[8] & 0x3F) | 0x80;

  char uuid[37];
  snprintf(
    uuid,
    sizeof(uuid),
    "%02x%02x%02x%02x-%02x%02x-%02x%02x-%02x%02x-%02x%02x%02x%02x%02x%02x",
    bytes[0], bytes[1], bytes[2], bytes[3],
    bytes[4], bytes[5], bytes[6], bytes[7],
    bytes[8], bytes[9], bytes[10], bytes[11],
    bytes[12], bytes[13], bytes[14], bytes[15]
  );

  return String(uuid);
}

String currentUtcIso() {
  time_t now = time(nullptr);

  if (now < 1609459200) {
    return "1970-01-01T00:00:00Z";
  }

  struct tm utcTime;
  gmtime_r(&now, &utcTime);

  char buffer[25];
  strftime(buffer, sizeof(buffer), "%Y-%m-%dT%H:%M:%SZ", &utcTime);
  return String(buffer);
}

bool parseIsoUtc(const char* value, time_t& parsedTime) {
  if (value == nullptr || strlen(value) != 20) {
    return false;
  }

  int year = 0;
  int month = 0;
  int day = 0;
  int hour = 0;
  int minute = 0;
  int second = 0;
  char suffix = '\0';

  int fields = sscanf(
    value,
    "%4d-%2d-%2dT%2d:%2d:%2d%c",
    &year,
    &month,
    &day,
    &hour,
    &minute,
    &second,
    &suffix
  );

  if (fields != 7 || suffix != 'Z') {
    return false;
  }

  if (year < 2020 || month < 1 || month > 12 || day < 1 ||
      hour < 0 || hour > 23 || minute < 0 || minute > 59 ||
      second < 0 || second > 59) {
    return false;
  }

  bool leapYear = (year % 4 == 0 && year % 100 != 0) ||
                  (year % 400 == 0);
  static const uint8_t DAYS_PER_MONTH[] = {
    31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31
  };
  int maximumDay = DAYS_PER_MONTH[month - 1];

  if (month == 2 && leapYear) {
    maximumDay = 29;
  }

  if (day > maximumDay) {
    return false;
  }

  // Portable Gregorian UTC conversion. This avoids timegm(), which is not
  // declared by every ESP32 Arduino toolchain, and avoids mktime() applying
  // the configured local timezone.
  int adjustedYear = year - (month <= 2 ? 1 : 0);
  int era = (adjustedYear >= 0 ? adjustedYear : adjustedYear - 399) / 400;
  unsigned yearOfEra =
    static_cast<unsigned>(adjustedYear - era * 400);
  unsigned adjustedMonth =
    static_cast<unsigned>(month + (month > 2 ? -3 : 9));
  unsigned dayOfYear =
    (153 * adjustedMonth + 2) / 5 + static_cast<unsigned>(day - 1);
  unsigned dayOfEra =
    yearOfEra * 365 + yearOfEra / 4 - yearOfEra / 100 + dayOfYear;
  int64_t daysSinceEpoch =
    static_cast<int64_t>(era) * 146097 + dayOfEra - 719468;
  int64_t epochSeconds =
    daysSinceEpoch * 86400LL + hour * 3600LL + minute * 60LL + second;

  parsedTime = static_cast<time_t>(epochSeconds);
  return parsedTime > 0;
}

bool setManualUtcTime(const char* value) {
  time_t parsedTime = 0;

  if (!parseIsoUtc(value, parsedTime)) {
    return false;
  }

  struct timeval systemTime;
  systemTime.tv_sec = parsedTime;
  systemTime.tv_usec = 0;
  return settimeofday(&systemTime, nullptr) == 0;
}

bool isValidTimezone(const char* timezone) {
  if (timezone == nullptr) {
    return false;
  }

  size_t length = strlen(timezone);

  if (length == 0 || length > 64) {
    return false;
  }

  for (size_t i = 0; i < length; ++i) {
    char character = timezone[i];
    bool valid = isalnum(static_cast<unsigned char>(character)) ||
                 character == '/' || character == '_' ||
                 character == '-' || character == '+';

    if (!valid) {
      return false;
    }
  }

  return true;
}

bool isJsonNumber(JsonVariantConst value) {
  return value.is<int>() || value.is<unsigned int>() ||
         value.is<long>() || value.is<unsigned long>() ||
         value.is<float>() || value.is<double>();
}

bool isAllowedBreakerValue(int value) {
  return value == 0 || value == 15 || value == 30 ||
         value == 40 || value == 60;
}

bool isAllowedFirmwareComponent(const char* component) {
  return component != nullptr &&
         (strcmp(component, "BDC") == 0 ||
          strcmp(component, "V2H") == 0 ||
          strcmp(component, "MSA") == 0);
}

bool isAllowedFirmwareStatus(const char* status) {
  if (status == nullptr) {
    return false;
  }

  static const char* VALUES[] = {
    "Idle",
    "Downloading",
    "Downloaded",
    "DownloadFailed",
    "Installing",
    "Installed",
    "InstallFailed",
    "InstallationComplete",
    "InstallRebooting"
  };

  for (const char* allowed : VALUES) {
    if (strcmp(status, allowed) == 0) {
      return true;
    }
  }

  return false;
}

String& firmwareStatusForComponent(const char* component) {
  if (strcmp(component, "V2H") == 0) {
    return v2hFirmwareStatus;
  }

  if (strcmp(component, "MSA") == 0) {
    return msaFirmwareStatus;
  }

  return bdcFirmwareStatus;
}

float simulatedCtL1Current() {
  return 12.4f + 0.15f * sinf(millis() / 3000.0f);
}

float simulatedCtL2Current() {
  return 11.9f + 0.12f * sinf(millis() / 2800.0f);
}

float simulatedChargeCurrentL1() {
  return 16.0f + 0.10f * sinf(millis() / 2400.0f);
}

float simulatedChargeCurrentL2() {
  return 16.0f + 0.10f * sinf(millis() / 2600.0f);
}

float simulatedMsaGridL1L2Voltage() {
  return 240.0f + 0.25f * sinf(millis() / 4100.0f);
}

float simulatedMsaGridL1Current() {
  return 5.2f + 0.08f * sinf(millis() / 3300.0f);
}

float simulatedMsaGridL2Current() {
  return 5.1f + 0.07f * sinf(millis() / 3600.0f);
}

float simulatedMsaLoadL1L2Voltage() {
  return 239.8f + 0.20f * sinf(millis() / 3900.0f);
}

const char* wifiSecurityName() {
  if (WiFi.status() != WL_CONNECTED) {
    return nullptr;
  }

  wifi_ap_record_t connectedAccessPoint = {};

  if (esp_wifi_sta_get_ap_info(&connectedAccessPoint) != ESP_OK) {
    return "Unknown";
  }

  int authenticationMode = static_cast<int>(connectedAccessPoint.authmode);

  switch (authenticationMode) {
    case 0:
      return "Open";
    case 1:
      return "WEP";
    case 2:
      return "WPA";
    case 3:
      return "WPA2";
    case 4:
      return "WPA/WPA2";
    case 6:
      return "WPA3";
    case 7:
      return "WPA2/WPA3";
    default:
      return "Enterprise/Unknown";
  }
}

void addSystemLogWithTime(const String& time, const String& message) {
  if (message.isEmpty()) {
    return;
  }

  size_t insertionLimit =
    systemLogEntryCount < MAX_SYSTEM_LOG_ENTRIES
      ? systemLogEntryCount
      : MAX_SYSTEM_LOG_ENTRIES - 1;

  for (size_t i = insertionLimit; i > 0; --i) {
    systemLogEntries[i] = systemLogEntries[i - 1];
  }

  systemLogEntries[0].time = time;
  systemLogEntries[0].message = message;

  if (systemLogEntryCount < MAX_SYSTEM_LOG_ENTRIES) {
    ++systemLogEntryCount;
  }
}

void addSystemLog(const String& message) {
  addSystemLogWithTime(currentUtcIso(), message);
}

void initializeSystemLog() {
  systemLogEntryCount = 0;

  // Add oldest first because addSystemLogWithTime stores newest first.
  addSystemLogWithTime("2026-06-24T16:09:30Z", "BDC startup complete");
  addSystemLogWithTime(
    "2026-06-24T16:09:35Z",
    "V2H communication established"
  );
  addSystemLogWithTime("2026-06-24T16:09:45Z", "Entered idle state");
  addSystemLogWithTime("2026-06-24T16:10:00Z", "Charging started");
  addSystemLogWithTime("2026-06-24T17:02:00Z", "Charging stopped");
}

bool isAllowedReferenceType(const char* type) {
  return type != nullptr &&
         (strcmp(type, "string") == 0 ||
          strcmp(type, "boolean") == 0 ||
          strcmp(type, "integer") == 0 ||
          strcmp(type, "number") == 0);
}

bool assignReferenceValue(
  ReferenceValueRecord& record,
  const char* key,
  const char* type,
  JsonVariantConst value
) {
  if (key == nullptr || type == nullptr || value.isNull() ||
      strlen(key) == 0 || strlen(key) > MAX_REFERENCE_KEY_LENGTH ||
      !isAllowedReferenceType(type)) {
    return false;
  }

  record = ReferenceValueRecord();
  record.key = key;
  record.type = type;

  if (strcmp(type, "string") == 0) {
    if (!value.is<const char*>()) {
      return false;
    }

    const char* stringValue = value.as<const char*>();

    if (stringValue == nullptr ||
        strlen(stringValue) > MAX_REFERENCE_STRING_LENGTH) {
      return false;
    }

    record.stringValue = stringValue;
    return true;
  }

  if (strcmp(type, "boolean") == 0) {
    if (!value.is<bool>()) {
      return false;
    }

    record.booleanValue = value.as<bool>();
    return true;
  }

  if (!isJsonNumber(value)) {
    return false;
  }

  double numericValue = value.as<double>();

  if (!isfinite(numericValue)) {
    return false;
  }

  if (strcmp(type, "integer") == 0) {
    if (floor(numericValue) != numericValue ||
        numericValue < -9007199254740991.0 ||
        numericValue > 9007199254740991.0) {
      return false;
    }

    record.integerValue = static_cast<int64_t>(numericValue);
    return true;
  }

  record.numberValue = numericValue;
  return true;
}

void addReferenceValueToJson(
  JsonObject destination,
  const ReferenceValueRecord& record
) {
  destination["key"] = record.key;
  destination["type"] = record.type;

  if (record.type == "string") {
    destination["value"] = record.stringValue;
  } else if (record.type == "boolean") {
    destination["value"] = record.booleanValue;
  } else if (record.type == "integer") {
    destination["value"] = record.integerValue;
  } else {
    destination["value"] = record.numberValue;
  }
}

int findReferenceValueIndex(
  const ReferenceValueRecord* records,
  size_t count,
  const char* key
) {
  if (key == nullptr) {
    return -1;
  }

  for (size_t i = 0; i < count; ++i) {
    if (records[i].key == key) {
      return static_cast<int>(i);
    }
  }

  return -1;
}

bool serializeReferenceValueSet(
  const ReferenceValueRecord* records,
  size_t count,
  String& serialized
) {
  JsonDocument document;
  JsonArray values = document["values"].to<JsonArray>();

  for (size_t i = 0; i < count; ++i) {
    JsonObject value = values.add<JsonObject>();
    addReferenceValueToJson(value, records[i]);
  }

  serialized = "";
  serializeJson(document, serialized);
  return serialized.length() <= MAX_REFERENCE_STORAGE_BYTES;
}

// =====================================================
// Preferences storage
// =====================================================

bool saveWifiCredentials(
  const String& ssid,
  const String& password,
  const char* securityType = nullptr
) {
  const char* effectiveSecurityType =
    securityType != nullptr
      ? securityType
      : (password.isEmpty() ? "OPEN" : "WPA2");

  JsonDocument record;
  record["ssid"] = ssid;
  record["password"] = password;
  record["security_type"] = effectiveSecurityType;
  String serializedRecord;
  serializeJson(record, serializedRecord);

  if (!preferences.begin("wifi-config", false)) {
    Serial.println("Failed to open Wi-Fi Preferences");
    return false;
  }

  // The authoritative credential set is one NVS value, so B02 cannot expose
  // a partially updated SSID/password/security tuple after power loss.
  size_t recordWritten = preferences.putString("record", serializedRecord);

  // Keep the older fields as migration mirrors for existing app builds.
  preferences.putString("ssid", ssid);
  preferences.putString("password", password);
  preferences.putString("security", effectiveSecurityType);
  preferences.putBool("configured", true);
  preferences.end();

  return recordWritten == serializedRecord.length();
}

bool loadWifiCredentials(String& ssid, String& password) {
  if (!preferences.begin("wifi-config", true)) {
    return false;
  }

  String serializedRecord = preferences.getString("record", "");
  bool configured = false;

  if (!serializedRecord.isEmpty()) {
    JsonDocument record;
    DeserializationError error = deserializeJson(record, serializedRecord);

    if (!error && record["ssid"].is<const char*>() &&
        record["password"].is<const char*>()) {
      ssid = record["ssid"].as<const char*>();
      password = record["password"].as<const char*>();
      configured = !ssid.isEmpty();
    }
  } else {
    configured = preferences.getBool("configured", false);
    ssid = preferences.getString("ssid", "");
    password = preferences.getString("password", "");
  }

  preferences.end();

  return configured && !ssid.isEmpty();
}

void clearWifiCredentials() {
  if (preferences.begin("wifi-config", false)) {
    preferences.clear();
    preferences.end();
  }

  WiFi.disconnect(false, true);
  WiFi.mode(WIFI_AP_STA);
  wifiConnecting = false;
  wifiCredentialsPersistedForAttempt = false;
  pendingSsid = "";
  pendingPassword = "";
  wifiConnectedSinceMs = 0;

  Serial.println("Stored Wi-Fi credentials deleted; SoftAP remains active");
}

void saveChargerConfiguration() {
  if (!preferences.begin("charger-config", false)) {
    Serial.println("Failed to open charger Preferences");
    return;
  }

  preferences.putString("timezone", configuredTimezone);
  preferences.putBool("backup", backupEnabled);
  preferences.putBool("bdcComm", bdcCommissioned);
  preferences.putBool("v2hComm", v2hCommissioned);
  preferences.putInt("breaker", commissioning.circuitBreakerValue);
  preferences.putString("throttle", commissioning.chargeThrottling);
  preferences.putFloat("panelLimit", commissioning.panelLimit);
  preferences.putFloat("demandLoad", commissioning.calculatedDemandLoad);
  preferences.putBool("invertL1", commissioning.invertCtL1);
  preferences.putBool("invertL2", commissioning.invertCtL2);
  preferences.putBool("cpCheck", commissioning.performCpCheckFlag);
  preferences.end();
}

void saveLifetimeMetrics() {
  if (!preferences.begin("charger-config", false)) {
    return;
  }

  preferences.putDouble("eCharged", lifetimeMetrics.energyChargedKwh);
  preferences.putDouble("eDischg", lifetimeMetrics.energyDischargedKwh);
  preferences.putDouble("hCharge", lifetimeMetrics.chargingHours);
  preferences.putDouble("hDischg", lifetimeMetrics.dischargingHours);
  preferences.end();
}

void loadPersistentState() {
  if (!preferences.begin("charger-config", true)) {
    return;
  }

  configuredTimezone = preferences.getString("timezone", "UTC");
  backupEnabled = preferences.getBool("backup", false);
  bdcCommissioned = preferences.getBool("bdcComm", false);
  v2hCommissioned = preferences.getBool("v2hComm", false);
  commissioning.circuitBreakerValue = preferences.getInt("breaker", 0);
  commissioning.chargeThrottling = preferences.getString("throttle", "static");
  commissioning.panelLimit = preferences.getFloat("panelLimit", 0.0f);
  commissioning.calculatedDemandLoad = preferences.getFloat("demandLoad", 0.0f);
  commissioning.invertCtL1 = preferences.getBool("invertL1", false);
  commissioning.invertCtL2 = preferences.getBool("invertL2", false);
  commissioning.performCpCheckFlag = preferences.getBool("cpCheck", false);
  lifetimeMetrics.energyChargedKwh = preferences.getDouble("eCharged", 1234.5);
  lifetimeMetrics.energyDischargedKwh = preferences.getDouble("eDischg", 678.9);
  lifetimeMetrics.chargingHours = preferences.getDouble("hCharge", 540.0);
  lifetimeMetrics.dischargingHours = preferences.getDouble("hDischg", 210.0);
  preferences.end();
}

bool persistReferenceValueSet(
  const ReferenceValueRecord* records,
  size_t count
) {
  String serialized;

  if (!serializeReferenceValueSet(records, count, serialized)) {
    return false;
  }

  if (!preferences.begin("reference-data", false)) {
    return false;
  }

  size_t bytesWritten = preferences.putString("records", serialized);
  preferences.end();
  return bytesWritten == serialized.length();
}

void loadReferenceValues() {
  referenceValueCount = 0;

  if (!preferences.begin("reference-data", true)) {
    return;
  }

  String serialized = preferences.getString("records", "");
  preferences.end();

  if (serialized.isEmpty()) {
    return;
  }

  JsonDocument document;
  DeserializationError error = deserializeJson(document, serialized);
  JsonArrayConst storedValues = document["values"].as<JsonArrayConst>();

  if (error || storedValues.isNull()) {
    Serial.println("Stored reference values are invalid; ignoring them");
    return;
  }

  for (JsonObjectConst storedValue : storedValues) {
    if (referenceValueCount >= MAX_REFERENCE_VALUES) {
      break;
    }

    const char* key = storedValue["key"];
    const char* type = storedValue["type"];

    if (!storedValue["key"].is<const char*>() ||
        !storedValue["type"].is<const char*>() ||
        !storedValue.containsKey("value") ||
        findReferenceValueIndex(referenceValues, referenceValueCount, key) >= 0) {
      continue;
    }

    ReferenceValueRecord record;

    if (!assignReferenceValue(record, key, type, storedValue["value"])) {
      continue;
    }

    referenceValues[referenceValueCount++] = record;
  }
}

void clearReferenceValues() {
  if (preferences.begin("reference-data", false)) {
    preferences.clear();
    preferences.end();
  }

  for (size_t i = 0; i < referenceValueCount; ++i) {
    referenceValues[i] = ReferenceValueRecord();
  }

  referenceValueCount = 0;
}

void resetChargerConfigurationToDefaults() {
  if (preferences.begin("charger-config", false)) {
    preferences.clear();
    preferences.end();
  }

  configuredTimezone = "UTC";
  backupEnabled = false;
  bdcCommissioned = false;
  v2hCommissioned = false;
  commissioning = CommissioningSettings();
  lifetimeMetrics = LifetimeMetrics();
}

// =====================================================
// BLE JSON output
// =====================================================

void sendBleJson(JsonDocument& document) {
  String response;
  serializeJson(document, response);

  if (responseCharacteristic != nullptr) {
    responseCharacteristic->setValue(response);

    if (bleClientConnected && responseNotificationsEnabled) {
      responseCharacteristic->notify();
    }
  }

  Serial.print("BLE TX: ");
  Serial.println(response);
}

void sendSimpleBleResponse(
  const char* command,
  const char* status,
  const char* message
) {
  JsonDocument response;
  response["cmd"] = command;
  response["status"] = status;
  response["message"] = message;
  sendBleJson(response);
}

void sendBleOperationError(
  const char* operation,
  const char* code,
  const char* description
) {
  JsonDocument response;
  response["operation"] = operation;
  response["status"] = "ERROR";
  JsonObject error = response["error"].to<JsonObject>();
  error["code"] = code;
  error["description"] = description;
  sendBleJson(response);
}

void addBleFirmwareComponents(JsonArray components) {
  JsonObject bdc = components.add<JsonObject>();
  bdc["component"] = "BDC";
  bdc["available"] = true;
  bdc["update_status"] = bdcFirmwareStatus;
  bdc["firmware_version"] =
    String("GW ") + BDC_GATEWAY_FW + " / MCU " + BDC_MCU_FW;

  JsonObject v2h = components.add<JsonObject>();
  v2h["component"] = "V2H";
  v2h["available"] = v2hInstalled;

  if (v2hInstalled) {
    v2h["update_status"] = v2hFirmwareStatus;
    v2h["firmware_version"] = V2H_FIRMWARE_VERSION;
  } else {
    v2h["update_status"] = nullptr;
    v2h["firmware_version"] = nullptr;
  }
}

void sendBleFirmwareUpdateStatus() {
  // Once commissioning WebSocket is active, M01 is authoritative and the
  // duplicate BLE notification is suppressed by the supplier protocol.
  if (activeWebSocketClients > 0) {
    return;
  }

  JsonDocument notification;
  notification["operation"] = "FW_UPDATE_STATUS";
  JsonArray components = notification["components"].to<JsonArray>();
  addBleFirmwareComponents(components);
  sendBleJson(notification);
}

// =====================================================
// WebSocket JSON envelope and output
// =====================================================

void beginResponse(
  JsonDocument& response,
  JsonDocument& request,
  const char* name,
  const char* status
) {
  const char* incomingMessageId = request["messageId"];
  String generatedMessageId;

  if (incomingMessageId != nullptr && strlen(incomingMessageId) > 0) {
    response["messageId"] = incomingMessageId;
  } else {
    generatedMessageId = makeUuid();
    response["messageId"] = generatedMessageId;
  }

  response["messageType"] = "Response";
  response["name"] = name;
  response["timestamp"] = currentUtcIso();
  response["source"] = "Charger";

  const char* requestSource = request["source"];
  response["destination"] =
    requestSource != nullptr && strlen(requestSource) > 0
      ? requestSource
      : "InstallerApp";

  response["status"] = status;
}

void beginEvent(JsonDocument& event, const char* name) {
  event["messageId"] = makeUuid();
  event["messageType"] = "Event";
  event["name"] = name;
  event["timestamp"] = currentUtcIso();
  event["source"] = "Charger";
  event["destination"] = "InstallerApp";
  event["status"] = "";
}

void sendWebSocketJson(uint8_t clientNumber, JsonDocument& document) {
  String response;
  serializeJson(document, response);
  webSocket.sendTXT(clientNumber, response);

  Serial.print("WS TX[");
  Serial.print(clientNumber);
  Serial.print("]: ");
  Serial.println(response);
}

void broadcastWebSocketJson(JsonDocument& document) {
  String message;
  serializeJson(document, message);
  webSocket.broadcastTXT(message);

  Serial.print("WS EVENT: ");
  Serial.println(message);
}

void sendWebSocketError(
  uint8_t clientNumber,
  JsonDocument& request,
  const char* name,
  const char* code,
  const char* description,
  bool includeLegacyErrorCode = false
) {
  JsonDocument response;
  beginResponse(response, request, name, "error");

  JsonObject error = response["error"].to<JsonObject>();
  error["code"] = code;
  error["description"] = description;

  if (includeLegacyErrorCode) {
    response["error_code"] = code;
  }

  sendWebSocketJson(clientNumber, response);
}

void sendWebSocketAcknowledgement(
  uint8_t clientNumber,
  JsonDocument& request,
  const char* name
) {
  JsonDocument response;
  beginResponse(response, request, name, "success");
  sendWebSocketJson(clientNumber, response);
}

// =====================================================
// Asynchronous M01 and M15 events
// Call these functions from real OTA/fault hardware logic.
// =====================================================

void broadcastFirmwareUpdateStatus(const char* component) {
  if (!isAllowedFirmwareComponent(component)) {
    return;
  }

  JsonDocument event;
  beginEvent(event, "FirmwareUpdateStatus");
  JsonObject payload = event["payload"].to<JsonObject>();
  payload["component"] = component;
  payload["status"] = firmwareStatusForComponent(component);
  payload["bdcFirmwareVersion"] =
    String("GW ") + BDC_GATEWAY_FW + " / MCU " + BDC_MCU_FW;

  if (v2hInstalled) {
    payload["v2hFirmwareVersion"] = V2H_FIRMWARE_VERSION;
  } else {
    payload["v2hFirmwareVersion"] = nullptr;
  }

  broadcastWebSocketJson(event);
}

bool setFirmwareUpdateStatus(const char* component, const char* status) {
  if (!isAllowedFirmwareComponent(component) ||
      !isAllowedFirmwareStatus(status)) {
    return false;
  }

  String& currentStatus = firmwareStatusForComponent(component);

  if (currentStatus == status) {
    return true;
  }

  currentStatus = status;
  addSystemLog(
    String(component) + " firmware status changed to " + String(status)
  );
  broadcastFirmwareUpdateStatus(component);
  sendBleFirmwareUpdateStatus();
  return true;
}

void addFaultRecord(
  const String& faultId,
  const String& time,
  const String& code,
  const String& description,
  const String& status
) {
  size_t limit = faultRecordCount < MAX_FAULT_RECORDS
                   ? faultRecordCount
                   : MAX_FAULT_RECORDS - 1;

  for (size_t i = limit; i > 0; --i) {
    faultRecords[i] = faultRecords[i - 1];
  }

  faultRecords[0] = {faultId, time, code, description, status};

  if (faultRecordCount < MAX_FAULT_RECORDS) {
    ++faultRecordCount;
  }
}

void reportFaultTransition(
  const char* code,
  const char* description,
  const char* status
) {
  if (code == nullptr || description == nullptr || status == nullptr ||
      (strcmp(status, "Active") != 0 && strcmp(status, "Inactive") != 0)) {
    return;
  }

  String faultId = makeUuid();
  String transitionTime = currentUtcIso();
  addFaultRecord(faultId, transitionTime, code, description, status);

  JsonDocument event;
  beginEvent(event, "FaultEvent");
  JsonObject payload = event["payload"].to<JsonObject>();
  payload["faultId"] = faultId;
  payload["time"] = transitionTime;
  payload["code"] = code;
  payload["faultDescription"] = description;
  payload["status"] = status;
  broadcastWebSocketJson(event);
  addSystemLog(
    String("BDC fault ") + code +
    (strcmp(status, "Active") == 0 ? " raised" : " cleared")
  );
}

void addMsaFaultHistoryRecord(
  const String& faultCode,
  const String& faultTime,
  const String& state
) {
  size_t insertionLimit =
    msaFaultHistoryCount < MAX_MSA_FAULT_HISTORY
      ? msaFaultHistoryCount
      : MAX_MSA_FAULT_HISTORY - 1;

  for (size_t i = insertionLimit; i > 0; --i) {
    msaFaultHistory[i] = msaFaultHistory[i - 1];
  }

  msaFaultHistory[0] = {faultCode, faultTime, state};

  if (msaFaultHistoryCount < MAX_MSA_FAULT_HISTORY) {
    ++msaFaultHistoryCount;
  }
}

void reportMsaFaultTransition(const char* faultCode, const char* state) {
  if (faultCode == nullptr || strlen(faultCode) == 0 || state == nullptr ||
      (strcmp(state, "raised") != 0 && strcmp(state, "cleared") != 0)) {
    return;
  }

  String transitionTime = currentUtcIso();
  addMsaFaultHistoryRecord(faultCode, transitionTime, state);

  if (strcmp(state, "raised") == 0) {
    activeMsaFaultCode = faultCode;
    activeMsaFaultTime = transitionTime;
  } else if (activeMsaFaultCode == faultCode) {
    activeMsaFaultCode = "";
    activeMsaFaultTime = "";
  }

  JsonDocument event;
  beginEvent(event, "MsaFaultEvent");
  JsonObject payload = event["payload"].to<JsonObject>();
  payload["faultCode"] = faultCode;
  payload["state"] = state;
  broadcastWebSocketJson(event);

  addSystemLog(
    String("MSA fault ") + faultCode + " " + String(state)
  );
}

void initializeMsaFaults() {
  msaFaultHistoryCount = 0;
  activeMsaFaultCode = "";
  activeMsaFaultTime = "";
}

void initializeSampleFaults() {
  faultRecordCount = 0;

  addFaultRecord(
    "c1baf0db-9b26-44d1-8f7a-5d9e4ac7c202",
    "2026-06-24T15:10:00Z",
    "20",
    "BDC cannot confirm home is islanded for discharge (no discharge occurs)",
    "Inactive"
  );

  addFaultRecord(
    "8f7f4a6e-4d2c-48bf-a4d9-2b0e07f1a101",
    "2026-06-24T16:54:30Z",
    "1",
    "BDC cannot turn off power mechanically",
    "Active"
  );
}

// =====================================================
// Wi-Fi and SoftAP management
// =====================================================

void sendWifiConnectingResponse() {
  JsonDocument response;
  response["cmd"] = "WIFI_CONNECTION_STATUS";
  response["status"] = "CONNECTING";
  response["ssid"] = pendingSsid;
  response["softap_ip"] = WiFi.softAPIP().toString();
  sendBleJson(response);
}

void sendWifiSuccessResponse() {
  JsonDocument response;
  response["cmd"] = "WIFI_CREDENTIALS_ACK";
  response["status"] = "SUCCESS";
  response["ssid"] = WiFi.SSID();
  response["ip_address"] = WiFi.localIP().toString();
  response["gateway"] = WiFi.gatewayIP().toString();
  response["rssi"] = WiFi.RSSI();
  response["softap_ip"] = WiFi.softAPIP().toString();
  response["websocket_url"] =
    String("ws://") + WiFi.softAPIP().toString() + ":" + WEBSOCKET_PORT + "/";
  sendBleJson(response);

  Serial.println();
  Serial.println("Wi-Fi connected successfully");
  Serial.print("SSID: ");
  Serial.println(WiFi.SSID());
  Serial.print("Station IP: ");
  Serial.println(WiFi.localIP());
  Serial.print("Gateway: ");
  Serial.println(WiFi.gatewayIP());
  Serial.print("Signal strength: ");
  Serial.print(WiFi.RSSI());
  Serial.println(" dBm");
}

void sendWifiFailureResponse(const char* reason) {
  JsonDocument response;
  response["cmd"] = "WIFI_CREDENTIALS_ACK";
  response["status"] = "FAILED";
  response["reason"] = reason;
  response["softap_ip"] = WiFi.softAPIP().toString();
  sendBleJson(response);
}

void startWifiConnection(
  const String& ssid,
  const String& password,
  bool notifyLegacyProtocol = true,
  bool credentialsAlreadyPersisted = false
) {
  if (ssid.isEmpty()) {
    sendWifiFailureResponse("SSID is empty");
    return;
  }

  pendingSsid = ssid;
  pendingPassword = password;
  wifiNotifyLegacyProtocol = notifyLegacyProtocol;
  wifiCredentialsPersistedForAttempt = credentialsAlreadyPersisted;

  // AP_STA keeps the installer connected to the charger SoftAP while the
  // station interface joins the customer's Wi-Fi network.
  WiFi.mode(WIFI_AP_STA);
  WiFi.disconnect(false, false);
  delay(100);

  Serial.println();
  Serial.println("Connecting station interface to Wi-Fi...");
  Serial.print("SSID: ");
  Serial.println(pendingSsid);

  WiFi.begin(pendingSsid.c_str(), pendingPassword.c_str());
  wifiConnectionStartTime = millis();
  wifiConnecting = true;

  if (wifiNotifyLegacyProtocol) {
    sendWifiConnectingResponse();
  }
}

void processWifiConnection() {
  wl_status_t currentStatus = WiFi.status();

  if (currentStatus == WL_CONNECTED && lastWifiStatus != WL_CONNECTED) {
    wifiConnectedSinceMs = millis();
    configTime(0, 0, "pool.ntp.org", "time.nist.gov");
    addSystemLog(String("Wi-Fi connected: ") + WiFi.SSID());
  }

  if (currentStatus != WL_CONNECTED && lastWifiStatus == WL_CONNECTED) {
    wifiConnectedSinceMs = 0;
    Serial.println("Station Wi-Fi disconnected; SoftAP/WebSocket remain active");
    addSystemLog("Wi-Fi disconnected");
  }

  lastWifiStatus = currentStatus;

  if (!wifiConnecting) {
    return;
  }

  if (currentStatus == WL_CONNECTED) {
    wifiConnecting = false;

    if (!wifiCredentialsPersistedForAttempt &&
        !saveWifiCredentials(pendingSsid, pendingPassword)) {
      Serial.println("Warning: connected, but Wi-Fi credentials were not saved");
    }

    if (wifiNotifyLegacyProtocol) {
      sendWifiSuccessResponse();
    }

    pendingPassword = "";
    return;
  }

  if (millis() - wifiConnectionStartTime >= WIFI_TIMEOUT_MS) {
    wifiConnecting = false;
    WiFi.disconnect(false, false);

    if (wifiNotifyLegacyProtocol) {
      sendWifiFailureResponse("Wi-Fi connection timed out");
    }

    pendingPassword = "";
    Serial.println("Wi-Fi connection timed out; SoftAP remains active");
    addSystemLog("Wi-Fi connection timed out");
  }
}

void startSoftApAndWebSocket() {
  WiFi.persistent(false);
  WiFi.mode(WIFI_AP_STA);
  WiFi.setAutoReconnect(true);

  softApReady = WiFi.softAP(SOFTAP_SSID, SOFTAP_PASSWORD);

  if (!softApReady) {
    Serial.println("ERROR: SoftAP failed to start");
    addSystemLog("SoftAP failed to start");
  } else {
    Serial.println("SoftAP started");
    Serial.print("SoftAP SSID: ");
    Serial.println(SOFTAP_SSID);
    Serial.print("SoftAP IP: ");
    Serial.println(WiFi.softAPIP());
    addSystemLog("SoftAP started");
  }

  webSocket.begin();
  webSocketReady = true;
  Serial.print("WebSocket URL: ws://");
  Serial.print(WiFi.softAPIP());
  Serial.print(":");
  Serial.print(WEBSOCKET_PORT);
  Serial.println("/");
}

// =====================================================
// BLE provisioning commands
// =====================================================

bool isSupportedBleSecurityType(const char* securityType) {
  return securityType != nullptr &&
         (strcmp(securityType, "OPEN") == 0 ||
          strcmp(securityType, "WPA2") == 0 ||
          strcmp(securityType, "WPA3") == 0 ||
          strcmp(securityType, "WPA2_WPA3") == 0);
}

void handleBleOperationWifiConfigCheck() {
  if (!preferences.begin("wifi-config", true)) {
    sendBleOperationError(
      "WIFI_CONFIG_STATUS",
      "READ_FAILED",
      "The stored Wi-Fi configuration could not be read."
    );
    return;
  }

  bool configured =
    preferences.getBool("configured", false) &&
    !preferences.getString("ssid", "").isEmpty();
  preferences.end();

  JsonDocument response;
  response["operation"] = "WIFI_CONFIG_STATUS";
  response["status"] = "SUCCESS";
  response["configured"] = configured;
  sendBleJson(response);
}

void handleBleOperationWifiCredentialsWrite(JsonDocument& request) {
  JsonVariantConst ssidValue = request["ssid"];
  JsonVariantConst passwordValue = request["password"];
  JsonVariantConst securityValue = request["security_type"];

  if (!ssidValue.is<const char*>() || !passwordValue.is<const char*>() ||
      !securityValue.is<const char*>()) {
    sendBleOperationError(
      "WIFI_CREDENTIALS_ACK",
      "INVALID_REQUEST",
      "ssid, password, and security_type are required strings."
    );
    return;
  }

  const char* ssid = ssidValue.as<const char*>();
  const char* password = passwordValue.as<const char*>();
  const char* securityType = securityValue.as<const char*>();

  if (ssid == nullptr || strlen(ssid) == 0 || strlen(ssid) > 32) {
    sendBleOperationError(
      "WIFI_CREDENTIALS_ACK",
      "INVALID_REQUEST",
      "ssid must contain 1 to 32 bytes."
    );
    return;
  }

  if (!isSupportedBleSecurityType(securityType)) {
    sendBleOperationError(
      "WIFI_CREDENTIALS_ACK",
      "INVALID_SECURITY_TYPE",
      "security_type is not supported."
    );
    return;
  }

  size_t passwordLength = strlen(password);
  bool openNetwork = strcmp(securityType, "OPEN") == 0;

  if ((openNetwork && passwordLength != 0) ||
      (!openNetwork && (passwordLength < 8 || passwordLength > 63))) {
    sendBleOperationError(
      "WIFI_CREDENTIALS_ACK",
      "INVALID_REQUEST",
      openNetwork
        ? "password must be empty for OPEN security."
        : "password must contain 8 to 63 bytes for secured Wi-Fi."
    );
    return;
  }

  if (wifiConnecting) {
    sendBleOperationError(
      "WIFI_CREDENTIALS_ACK",
      "WRITE_BUSY",
      "A Wi-Fi connection attempt is already in progress."
    );
    return;
  }

  // B02 success means the complete credential set was structurally accepted
  // and persisted atomically. Association is deliberately not part of ACK.
  if (!saveWifiCredentials(ssid, password, securityType)) {
    sendBleOperationError(
      "WIFI_CREDENTIALS_ACK",
      "WRITE_FAILED",
      "Wi-Fi credentials could not be persisted."
    );
    return;
  }

  JsonDocument response;
  response["operation"] = "WIFI_CREDENTIALS_ACK";
  response["status"] = "SUCCESS";
  sendBleJson(response);

  startWifiConnection(String(ssid), String(password), false, true);
}

void handleBleOperationFirmwareStatusCheck() {
  JsonDocument response;
  response["operation"] = "FW_STATUS_RESPONSE";
  response["status"] = "SUCCESS";
  JsonArray components = response["components"].to<JsonArray>();
  addBleFirmwareComponents(components);
  sendBleJson(response);
}

void handleBleOperationSoftApEnable() {
  if (!softApReady || !webSocketReady ||
      WiFi.softAPIP() == IPAddress(0, 0, 0, 0)) {
    sendBleOperationError(
      "SOFTAP_ENABLE_RESPONSE",
      "SOFTAP_START_FAILED",
      "SoftAP or the WebSocket listener did not become ready."
    );
    return;
  }

  JsonDocument response;
  response["operation"] = "SOFTAP_ENABLE_RESPONSE";
  response["status"] = "SUCCESS";
  response["softap_ssid"] = SOFTAP_SSID;
  response["softap_password"] = SOFTAP_PASSWORD;
  response["local_ip"] = WiFi.softAPIP().toString();
  response["websocket_url"] =
    String("ws://") + WiFi.softAPIP().toString() + ":" +
    WEBSOCKET_PORT + "/";
  sendBleJson(response);
}

void processBleOperation(const char* operation, JsonDocument& request) {
  if (strcmp(operation, "WIFI_CONFIG_CHECK") == 0) {
    handleBleOperationWifiConfigCheck();
  } else if (strcmp(operation, "WIFI_CREDENTIALS_WRITE") == 0) {
    handleBleOperationWifiCredentialsWrite(request);
  } else if (strcmp(operation, "FW_STATUS_CHECK") == 0) {
    handleBleOperationFirmwareStatusCheck();
  } else if (strcmp(operation, "SOFTAP_ENABLE") == 0) {
    handleBleOperationSoftApEnable();
  } else {
    sendBleOperationError(
      operation,
      "INVALID_REQUEST",
      "Unknown BLE operation."
    );
  }
}

void handleBleWifiConfigCheck() {
  String storedSsid;
  String storedPassword;
  bool configured = loadWifiCredentials(storedSsid, storedPassword);

  JsonDocument response;
  response["cmd"] = "WIFI_CONFIG_STATUS";
  response["configured"] = configured;

  if (configured) {
    response["ssid"] = storedSsid;
  }

  response["wifi_connected"] = WiFi.status() == WL_CONNECTED;
  response["softap_ip"] = WiFi.softAPIP().toString();
  response["websocket_url"] =
    String("ws://") + WiFi.softAPIP().toString() + ":" + WEBSOCKET_PORT + "/";

  if (WiFi.status() == WL_CONNECTED) {
    response["ip_address"] = WiFi.localIP().toString();
  }

  sendBleJson(response);
  storedPassword = "";
}

void handleBleWifiCredentialsWrite(JsonDocument& request) {
  const char* ssid = request["ssid"];
  const char* password = request["password"];

  if (ssid == nullptr || strlen(ssid) == 0) {
    sendWifiFailureResponse("Missing or empty ssid");
    return;
  }

  if (password == nullptr) {
    sendWifiFailureResponse("Missing password");
    return;
  }

  if (wifiConnecting) {
    sendWifiFailureResponse("Wi-Fi connection already in progress");
    return;
  }

  startWifiConnection(String(ssid), String(password));
}

void handleBleGetIpAddress() {
  JsonDocument response;
  response["cmd"] = "IP_ADDRESS_RESPONSE";
  response["softap_ip"] = WiFi.softAPIP().toString();
  response["websocket_url"] =
    String("ws://") + WiFi.softAPIP().toString() + ":" + WEBSOCKET_PORT + "/";

  if (WiFi.status() == WL_CONNECTED) {
    response["status"] = "SUCCESS";
    response["ip_address"] = WiFi.localIP().toString();
    response["ssid"] = WiFi.SSID();
  } else {
    response["status"] = "FAILED";
    response["reason"] = "Station Wi-Fi is not connected";
  }

  sendBleJson(response);
}

void handleBleClearWifiConfig() {
  clearWifiCredentials();

  JsonDocument response;
  response["cmd"] = "WIFI_CONFIG_CLEAR_ACK";
  response["status"] = "SUCCESS";
  response["softap_ip"] = WiFi.softAPIP().toString();
  sendBleJson(response);
}

void processBleCommand(
  const std::string& receivedValue,
  NimBLEConnInfo& connectionInfo
) {
  Serial.print("BLE RX: ");
  Serial.println(receivedValue.c_str());

  if (!connectionInfo.isEncrypted()) {
    sendSimpleBleResponse(
      "ERROR",
      "UNAUTHORIZED",
      "BLE connection is not encrypted"
    );
    return;
  }

  JsonDocument request;
  DeserializationError error = deserializeJson(request, receivedValue);

  if (error) {
    sendSimpleBleResponse("ERROR", "FAILED", "Invalid JSON");
    return;
  }

  const char* operation = request["operation"];

  if (operation != nullptr && strlen(operation) > 0) {
    processBleOperation(operation, request);
    return;
  }

  const char* command = request["cmd"];

  if (command == nullptr) {
    sendSimpleBleResponse(
      "ERROR",
      "FAILED",
      "Missing operation or cmd field"
    );
    return;
  }

  if (strcmp(command, "WIFI_CONFIG_CHECK") == 0) {
    handleBleWifiConfigCheck();
  } else if (strcmp(command, "WIFI_CREDENTIALS_WRITE") == 0) {
    handleBleWifiCredentialsWrite(request);
  } else if (strcmp(command, "GET_IP_ADDRESS") == 0) {
    handleBleGetIpAddress();
  } else if (strcmp(command, "WIFI_CONFIG_CLEAR") == 0) {
    handleBleClearWifiConfig();
  } else if (strcmp(command, "PING") == 0) {
    sendSimpleBleResponse("PONG", "SUCCESS", "ESP32 is connected");
  } else {
    sendSimpleBleResponse(command, "FAILED", "Unknown command");
  }
}

// =====================================================
// M01-M25 WebSocket handlers
// =====================================================

void handleGetFirmwareUpdateStatus(
  uint8_t clientNumber,
  JsonDocument& request,
  JsonObjectConst requestPayload
) {
  const char* component = "BDC";

  if (!requestPayload.isNull() && requestPayload.containsKey("component")) {
    component = requestPayload["component"];

    if (!isAllowedFirmwareComponent(component)) {
      sendWebSocketError(
        clientNumber,
        request,
        "GetFirmwareUpdateStatus",
        "INVALID_REQUEST",
        "component must be BDC, V2H, or MSA."
      );
      return;
    }
  }

  JsonDocument response;
  beginResponse(response, request, "GetFirmwareUpdateStatus", "success");
  JsonObject payload = response["payload"].to<JsonObject>();
  payload["component"] = component;
  payload["status"] = firmwareStatusForComponent(component);
  payload["bdcFirmwareVersion"] =
    String("GW ") + BDC_GATEWAY_FW + " / MCU " + BDC_MCU_FW;

  if (v2hInstalled) {
    payload["v2hFirmwareVersion"] = V2H_FIRMWARE_VERSION;
  } else {
    payload["v2hFirmwareVersion"] = nullptr;
  }

  sendWebSocketJson(clientNumber, response);
}

void handleSetTimeConfig(
  uint8_t clientNumber,
  JsonDocument& request,
  JsonObjectConst requestPayload
) {
  if (requestPayload.isNull()) {
    sendWebSocketError(
      clientNumber,
      request,
      "SetTimeConfig",
      "INVALID_REQUEST",
      "payload must contain timezone and/or manualSetBdcTime."
    );
    return;
  }

  bool hasTimezone = requestPayload.containsKey("timezone");
  bool hasManualTime = requestPayload.containsKey("manualSetBdcTime");

  if (!hasTimezone && !hasManualTime) {
    sendWebSocketError(
      clientNumber,
      request,
      "SetTimeConfig",
      "INVALID_REQUEST",
      "At least one time configuration field is required."
    );
    return;
  }

  if (hasTimezone) {
    const char* timezone = requestPayload["timezone"];

    if (!requestPayload["timezone"].is<const char*>() ||
        !isValidTimezone(timezone)) {
      sendWebSocketError(
        clientNumber,
        request,
        "SetTimeConfig",
        "INVALID_REQUEST",
        "timezone must be a valid non-empty IANA timezone string."
      );
      return;
    }
  }

  if (hasManualTime) {
    const char* manualTime = requestPayload["manualSetBdcTime"];

    if (!requestPayload["manualSetBdcTime"].is<const char*>() ||
        !setManualUtcTime(manualTime)) {
      sendWebSocketError(
        clientNumber,
        request,
        "SetTimeConfig",
        "INVALID_REQUEST",
        "manualSetBdcTime must be ISO-8601 UTC, for example 2026-08-03T18:40:00Z."
      );
      return;
    }
  }

  if (hasTimezone) {
    configuredTimezone = requestPayload["timezone"].as<const char*>();
  }

  saveChargerConfiguration();
  sendWebSocketAcknowledgement(clientNumber, request, "SetTimeConfig");
}

void handleGetTimeConfig(uint8_t clientNumber, JsonDocument& request) {
  JsonDocument response;
  beginResponse(response, request, "GetTimeConfig", "success");
  JsonObject payload = response["payload"].to<JsonObject>();
  payload["timezoneRead"] = configuredTimezone;
  payload["bdcTime"] = currentUtcIso();
  sendWebSocketJson(clientNumber, response);
}

bool isCommissioningField(const char* key) {
  return strcmp(key, "circuitBreakerValue") == 0 ||
         strcmp(key, "chargeThrottling") == 0 ||
         strcmp(key, "panelLimit") == 0 ||
         strcmp(key, "calculatedDemandLoad") == 0 ||
         strcmp(key, "invertCtL1") == 0 ||
         strcmp(key, "invertCtL2") == 0 ||
         strcmp(key, "performCpCheckFlag") == 0;
}

void handleSetCommissioningSettings(
  uint8_t clientNumber,
  JsonDocument& request,
  JsonObjectConst requestPayload
) {
  if (requestPayload.isNull() || requestPayload.size() == 0) {
    sendWebSocketError(
      clientNumber,
      request,
      "SetCommissioningSettings",
      "INVALID_REQUEST",
      "At least one commissioning setting is required."
    );
    return;
  }

  bool recognizedFieldFound = false;

  for (JsonPairConst field : requestPayload) {
    const char* key = field.key().c_str();

    if (!isCommissioningField(key) || field.value().isNull()) {
      sendWebSocketError(
        clientNumber,
        request,
        "SetCommissioningSettings",
        "INVALID_REQUEST",
        "Payload contains an unknown or null commissioning parameter."
      );
      return;
    }

    recognizedFieldFound = true;
  }

  if (!recognizedFieldFound) {
    sendWebSocketError(
      clientNumber,
      request,
      "SetCommissioningSettings",
      "INVALID_REQUEST",
      "At least one recognized commissioning setting is required."
    );
    return;
  }

  if (requestPayload.containsKey("circuitBreakerValue")) {
    if (!requestPayload["circuitBreakerValue"].is<int>() ||
        !isAllowedBreakerValue(requestPayload["circuitBreakerValue"].as<int>())) {
      sendWebSocketError(
        clientNumber,
        request,
        "SetCommissioningSettings",
        "INVALID_REQUEST",
        "circuitBreakerValue must be 0, 15, 30, 40, or 60."
      );
      return;
    }
  }

  if (requestPayload.containsKey("chargeThrottling")) {
    const char* throttling = requestPayload["chargeThrottling"];

    if (!requestPayload["chargeThrottling"].is<const char*>() ||
        (strcmp(throttling, "static") != 0 && strcmp(throttling, "dynamic") != 0)) {
      sendWebSocketError(
        clientNumber,
        request,
        "SetCommissioningSettings",
        "INVALID_REQUEST",
        "chargeThrottling must be static or dynamic."
      );
      return;
    }
  }

  const char* numericFields[] = {"panelLimit", "calculatedDemandLoad"};

  for (const char* field : numericFields) {
    if (requestPayload.containsKey(field)) {
      JsonVariantConst value = requestPayload[field];
      double number = value.as<double>();

      if (!isJsonNumber(value) || !isfinite(number) || number < 0.0) {
        sendWebSocketError(
          clientNumber,
          request,
          "SetCommissioningSettings",
          "INVALID_REQUEST",
          "panelLimit and calculatedDemandLoad must be non-negative numbers."
        );
        return;
      }
    }
  }

  const char* booleanFields[] = {
    "invertCtL1",
    "invertCtL2",
    "performCpCheckFlag"
  };

  for (const char* field : booleanFields) {
    if (requestPayload.containsKey(field) && !requestPayload[field].is<bool>()) {
      sendWebSocketError(
        clientNumber,
        request,
        "SetCommissioningSettings",
        "INVALID_REQUEST",
        "CT inversion and CP check fields must be Boolean."
      );
      return;
    }
  }

  if (requestPayload.containsKey("circuitBreakerValue")) {
    commissioning.circuitBreakerValue = requestPayload["circuitBreakerValue"];
  }

  if (requestPayload.containsKey("chargeThrottling")) {
    commissioning.chargeThrottling =
      requestPayload["chargeThrottling"].as<const char*>();
  }

  if (requestPayload.containsKey("panelLimit")) {
    commissioning.panelLimit = requestPayload["panelLimit"].as<float>();
  }

  if (requestPayload.containsKey("calculatedDemandLoad")) {
    commissioning.calculatedDemandLoad =
      requestPayload["calculatedDemandLoad"].as<float>();
  }

  if (requestPayload.containsKey("invertCtL1")) {
    commissioning.invertCtL1 = requestPayload["invertCtL1"].as<bool>();
  }

  if (requestPayload.containsKey("invertCtL2")) {
    commissioning.invertCtL2 = requestPayload["invertCtL2"].as<bool>();
  }

  if (requestPayload.containsKey("performCpCheckFlag")) {
    commissioning.performCpCheckFlag =
      requestPayload["performCpCheckFlag"].as<bool>();
  }

  saveChargerConfiguration();
  sendWebSocketAcknowledgement(clientNumber, request, "SetCommissioningSettings");
}

void addCommissioningPayload(JsonObject payload) {
  payload["circuitBreakerValue"] = commissioning.circuitBreakerValue;
  payload["chargeThrottling"] = commissioning.chargeThrottling;
  payload["panelLimit"] = commissioning.panelLimit;
  payload["calculatedDemandLoad"] = commissioning.calculatedDemandLoad;
  payload["invertCtL1"] = commissioning.invertCtL1;
  payload["invertCtL2"] = commissioning.invertCtL2;
  payload["performCpCheckFlag"] = commissioning.performCpCheckFlag;
}

void handleGetCommissioningSettings(
  uint8_t clientNumber,
  JsonDocument& request
) {
  JsonDocument response;
  beginResponse(response, request, "GetCommissioningSettings", "success");
  JsonObject payload = response["payload"].to<JsonObject>();
  addCommissioningPayload(payload);
  sendWebSocketJson(clientNumber, response);
}

void handleGetCtClampStatus(uint8_t clientNumber, JsonDocument& request) {
  bool l1Detected = true;
  bool l2Detected = true;

  JsonDocument response;
  beginResponse(response, request, "GetCtClampStatus", "success");
  JsonObject payload = response["payload"].to<JsonObject>();
  payload["l1Detected"] = l1Detected;
  payload["l2Detected"] = l2Detected;

  if (l1Detected) {
    payload["l1Reading"] = simulatedCtL1Current();
  } else {
    payload["l1Reading"] = nullptr;
  }

  if (l2Detected) {
    payload["l2Reading"] = simulatedCtL2Current();
  } else {
    payload["l2Reading"] = nullptr;
  }

  sendWebSocketJson(clientNumber, response);
}

void handleSetBackupEnable(
  uint8_t clientNumber,
  JsonDocument& request,
  JsonObjectConst requestPayload
) {
  if (requestPayload.isNull() ||
      !requestPayload.containsKey("enable") ||
      !requestPayload["enable"].is<bool>()) {
    sendWebSocketError(
      clientNumber,
      request,
      "SetBackupEnable",
      "INVALID_REQUEST",
      "enable is required and must be Boolean."
    );
    return;
  }

  backupEnabled = requestPayload["enable"].as<bool>();
  saveChargerConfiguration();
  sendWebSocketAcknowledgement(clientNumber, request, "SetBackupEnable");
}

void handleGetBackupEnable(uint8_t clientNumber, JsonDocument& request) {
  JsonDocument response;
  beginResponse(response, request, "GetBackupEnable", "success");
  JsonObject payload = response["payload"].to<JsonObject>();
  payload["enabled"] = backupEnabled;
  sendWebSocketJson(clientNumber, response);
}

void handleCheckMsaInstall(uint8_t clientNumber, JsonDocument& request) {
  JsonDocument response;
  beginResponse(response, request, "CheckMsaInstall", "success");
  JsonObject payload = response["payload"].to<JsonObject>();
  payload["result"] = msaInstalled ? "communicating" : "notDetected";
  sendWebSocketJson(clientNumber, response);
}

void clearCurrentlyActiveFaults() {
  String activeCodes[MAX_FAULT_RECORDS];
  String activeDescriptions[MAX_FAULT_RECORDS];
  String seenCodes[MAX_FAULT_RECORDS];
  size_t activeCount = 0;
  size_t seenCount = 0;

  // The first record for a code is its newest/current transition.
  for (size_t i = 0; i < faultRecordCount; ++i) {
    bool alreadySeen = false;

    for (size_t j = 0; j < seenCount; ++j) {
      if (seenCodes[j] == faultRecords[i].code) {
        alreadySeen = true;
        break;
      }
    }

    if (alreadySeen) {
      continue;
    }

    seenCodes[seenCount++] = faultRecords[i].code;

    if (faultRecords[i].status == "Active") {
      activeCodes[activeCount] = faultRecords[i].code;
      activeDescriptions[activeCount] = faultRecords[i].description;
      ++activeCount;
    }
  }

  for (size_t i = 0; i < activeCount; ++i) {
    reportFaultTransition(
      activeCodes[i].c_str(),
      activeDescriptions[i].c_str(),
      "Inactive"
    );
  }
}

void scheduleSystemAction(PendingSystemAction action) {
  pendingSystemAction = action;
  pendingSystemActionAtMs = millis();
}

void handleSystemCommand(
  uint8_t clientNumber,
  JsonDocument& request,
  JsonObjectConst requestPayload
) {
  const char* command = requestPayload["command"];

  if (requestPayload.isNull() ||
      !requestPayload["command"].is<const char*>() ||
      command == nullptr) {
    sendWebSocketError(
      clientNumber,
      request,
      "SystemCommand",
      "INVALID_REQUEST",
      "command is required and must be a string.",
      true
    );
    return;
  }

  if (strcmp(command, "clearCriticalFaults") == 0) {
    sendWebSocketAcknowledgement(clientNumber, request, "SystemCommand");
    clearCurrentlyActiveFaults();
    return;
  }

  if (strcmp(command, "remoteReboot") == 0) {
    sendWebSocketAcknowledgement(clientNumber, request, "SystemCommand");
    scheduleSystemAction(PendingSystemAction::RemoteReboot);
    return;
  }

  if (strcmp(command, "eraseCustomerData") == 0) {
    sendWebSocketAcknowledgement(clientNumber, request, "SystemCommand");
    scheduleSystemAction(PendingSystemAction::EraseCustomerData);
    return;
  }

  if (strcmp(command, "factoryReset") == 0) {
    sendWebSocketAcknowledgement(clientNumber, request, "SystemCommand");
    scheduleSystemAction(PendingSystemAction::FactoryReset);
    return;
  }

  sendWebSocketError(
    clientNumber,
    request,
    "SystemCommand",
    "REQUEST_NOT_ALLOWED",
    "Unsupported system command.",
    true
  );
}

void handleGetCommissionRecordFlag(
  uint8_t clientNumber,
  JsonDocument& request
) {
  const char* record = "none";

  if (bdcCommissioned && v2hCommissioned) {
    record = "bdcAndV2h";
  } else if (bdcCommissioned) {
    record = "bdcOnly";
  }

  JsonDocument response;
  beginResponse(response, request, "GetCommissionRecordFlag", "success");
  JsonObject payload = response["payload"].to<JsonObject>();
  payload["commissionedRecord"] = record;
  sendWebSocketJson(clientNumber, response);
}

void handleUpdateCommissionRecordFlag(
  uint8_t clientNumber,
  JsonDocument& request,
  JsonObjectConst requestPayload
) {
  bool hasBdc = requestPayload.containsKey("setBdcCommissioned");
  bool hasV2h = requestPayload.containsKey("setV2hCommissioned");

  if (requestPayload.isNull() || (!hasBdc && !hasV2h)) {
    sendWebSocketError(
      clientNumber,
      request,
      "UpdateCommissionRecordFlag",
      "INVALID_REQUEST",
      "At least one commissioning record field is required."
    );
    return;
  }

  if ((hasBdc && !requestPayload["setBdcCommissioned"].is<bool>()) ||
      (hasV2h && !requestPayload["setV2hCommissioned"].is<bool>())) {
    sendWebSocketError(
      clientNumber,
      request,
      "UpdateCommissionRecordFlag",
      "INVALID_REQUEST",
      "Commissioning record fields must be Boolean."
    );
    return;
  }

  if (hasBdc) {
    bdcCommissioned = requestPayload["setBdcCommissioned"].as<bool>();
  }

  if (hasV2h) {
    v2hCommissioned = requestPayload["setV2hCommissioned"].as<bool>();
  }

  // bdcAndV2h is the only valid V2H-commissioned state.
  if (v2hCommissioned) {
    bdcCommissioned = true;
  }

  saveChargerConfiguration();
  Serial.println("Commission record updated from Installer App Event");

  // M09 defines UpdateCommissionRecordFlag as an Event, so no success
  // Response is sent. Validation failures above still return an error.
}

void handleGetBdcDeviceInfo(uint8_t clientNumber, JsonDocument& request) {
  JsonDocument response;
  beginResponse(response, request, "GetBdcDeviceInfo", "success");
  JsonObject payload = response["payload"].to<JsonObject>();
  payload["serialNumber"] = BDC_SERIAL_NUMBER;
  payload["modelNumber"] = BDC_MODEL_NUMBER;
  payload["gatewayFirmwareVersion"] = BDC_GATEWAY_FW;
  payload["mcuFirmwareVersion"] = BDC_MCU_FW;
  payload["firstBootDate"] = BDC_FIRST_BOOT_DATE;
  payload["dateOfManufacture"] = BDC_MANUFACTURE_DATE;
  payload["currentMeasurementSource"] = "CT clamps";
  sendWebSocketJson(clientNumber, response);
}

void handleGetNetworkStatus(uint8_t clientNumber, JsonDocument& request) {
  bool connected = WiFi.status() == WL_CONNECTED;

  JsonDocument response;
  beginResponse(response, request, "GetNetworkStatus", "success");
  JsonObject payload = response["payload"].to<JsonObject>();

  if (connected) {
    payload["wifiSsid"] = WiFi.SSID();
    payload["wifiRssi"] = WiFi.RSSI();
    payload["wifiConnectionUptime"] =
      wifiConnectedSinceMs == 0
        ? 0
        : static_cast<uint32_t>((millis() - wifiConnectedSinceMs) / 1000UL);
    payload["wifiFrequency"] = 2.4;
    payload["wifiSecurity"] = wifiSecurityName();

    // This simulator treats an established station link as Internet-ready.
    // Replace this with the product's actual Internet health check.
    payload["internetConnectionUptime"] =
      wifiConnectedSinceMs == 0
        ? 0
        : static_cast<uint32_t>((millis() - wifiConnectedSinceMs) / 1000UL);
    payload["internetConnectivity"] = "connected";
  } else {
    payload["wifiSsid"] = nullptr;
    payload["wifiRssi"] = nullptr;
    payload["wifiConnectionUptime"] = nullptr;
    payload["wifiFrequency"] = nullptr;
    payload["wifiSecurity"] = nullptr;
    payload["internetConnectionUptime"] = nullptr;
    payload["internetConnectivity"] = "disconnected";
  }

  sendWebSocketJson(clientNumber, response);
}

void handleGetVehicleStatus(uint8_t clientNumber, JsonDocument& request) {
  JsonDocument response;
  beginResponse(response, request, "GetVehicleStatus", "success");
  JsonObject payload = response["payload"].to<JsonObject>();
  payload["vehicleConnectedStatus"] = "Charging: plugged-in";
  sendWebSocketJson(clientNumber, response);
}

void handleGetPowerMeasurements(uint8_t clientNumber, JsonDocument& request) {
  JsonDocument response;
  beginResponse(response, request, "GetPowerMeasurements", "success");
  JsonObject payload = response["payload"].to<JsonObject>();

  JsonObject chargeCurrent = payload["chargeCurrentL1L2"].to<JsonObject>();
  chargeCurrent["L1"] = simulatedChargeCurrentL1();
  chargeCurrent["L2"] = simulatedChargeCurrentL2();

  JsonObject dischargeCurrent =
    payload["dischargeCurrentL1L2"].to<JsonObject>();
  dischargeCurrent["L1"] = 0.0;
  dischargeCurrent["L2"] = 0.0;

  payload["voltageL1L2"] = 240.1;
  payload["status"] = "Charging";

  JsonObject state = payload["state"].to<JsonObject>();
  state["code"] = "CHARGING";
  state["description"] = "Actively charging the vehicle.";

  sendWebSocketJson(clientNumber, response);
}

void handleGetChargeEventLog(uint8_t clientNumber, JsonDocument& request) {
  JsonDocument response;
  beginResponse(response, request, "GetChargeEventLog", "success");
  JsonObject payload = response["payload"].to<JsonObject>();
  JsonArray events = payload["events"].to<JsonArray>();

  for (const ChargeEventRecord& record : CHARGE_EVENTS) {
    JsonObject event = events.add<JsonObject>();
    event["start"] = record.start;
    event["end"] = record.end;
    event["energyKWh"] = record.energyKWh;
  }

  sendWebSocketJson(clientNumber, response);
}

void handleGetFaults(uint8_t clientNumber, JsonDocument& request) {
  JsonDocument response;
  beginResponse(response, request, "GetFaults", "success");
  JsonObject payload = response["payload"].to<JsonObject>();
  JsonArray faults = payload["faults"].to<JsonArray>();

  for (size_t i = 0; i < faultRecordCount; ++i) {
    JsonObject fault = faults.add<JsonObject>();
    fault["faultId"] = faultRecords[i].faultId;
    fault["time"] = faultRecords[i].time;
    fault["code"] = faultRecords[i].code;
    fault["faultDescription"] = faultRecords[i].description;
    fault["status"] = faultRecords[i].status;
  }

  sendWebSocketJson(clientNumber, response);
}

void handleGetLifetimeMetrics(uint8_t clientNumber, JsonDocument& request) {
  JsonDocument response;
  beginResponse(response, request, "GetLifetimeMetrics", "success");
  JsonObject payload = response["payload"].to<JsonObject>();
  payload["energyChargedKwh"] = lifetimeMetrics.energyChargedKwh;
  payload["energyDischargedKwh"] = lifetimeMetrics.energyDischargedKwh;
  payload["chargingHours"] = lifetimeMetrics.chargingHours;
  payload["dischargingHours"] = lifetimeMetrics.dischargingHours;
  sendWebSocketJson(clientNumber, response);
}

void handleGetV2hDeviceInfo(uint8_t clientNumber, JsonDocument& request) {
  JsonDocument response;
  beginResponse(response, request, "GetV2hDeviceInfo", "success");
  JsonObject payload = response["payload"].to<JsonObject>();

  if (v2hInstalled) {
    payload["serialNumber"] = V2H_SERIAL_NUMBER;
    payload["modelNumber"] = V2H_MODEL_NUMBER;
    payload["firmwareVersion"] = V2H_FIRMWARE_VERSION;
    payload["firstBootDate"] = V2H_FIRST_BOOT_DATE;
    payload["dateOfManufacture"] = V2H_MANUFACTURE_DATE;
  } else {
    payload["serialNumber"] = nullptr;
    payload["modelNumber"] = nullptr;
    payload["firmwareVersion"] = nullptr;
    payload["firstBootDate"] = nullptr;
    payload["dateOfManufacture"] = nullptr;
  }

  sendWebSocketJson(clientNumber, response);
}

void handleGetV2hMeasurements(uint8_t clientNumber, JsonDocument& request) {
  JsonDocument response;
  beginResponse(response, request, "GetV2hMeasurements", "success");
  JsonObject payload = response["payload"].to<JsonObject>();
  payload["gridL1nVoltage"] = 120.2;
  payload["gridL2nVoltage"] = 119.9;
  payload["ipsSoc"] = 87;
  payload["ipsRemainingBackupEvents"] = 12;
  payload["ipsNeedsReplacement"] = false;
  sendWebSocketJson(clientNumber, response);
}

void handleGetBackupEventLog(uint8_t clientNumber, JsonDocument& request) {
  JsonDocument response;
  beginResponse(response, request, "GetBackupEventLog", "success");
  JsonObject payload = response["payload"].to<JsonObject>();
  JsonArray events = payload["events"].to<JsonArray>();

  for (const BackupEventRecord& record : BACKUP_EVENTS) {
    JsonObject event = events.add<JsonObject>();
    event["start"] = record.start;
    event["end"] = record.end;
    event["durationMinutes"] = record.durationMinutes;
    event["peakPowerKw"] = record.peakPowerKw;
    event["energyKwh"] = record.energyKwh;
  }

  sendWebSocketJson(clientNumber, response);
}

void handleGetCtMeasurements(uint8_t clientNumber, JsonDocument& request) {
  JsonDocument response;
  beginResponse(response, request, "GetCtMeasurements", "success");
  JsonObject payload = response["payload"].to<JsonObject>();
  payload["ctL1Current"] = simulatedCtL1Current();
  payload["ctL2Current"] = simulatedCtL2Current();
  sendWebSocketJson(clientNumber, response);
}

void handleGetMsaDeviceInfo(uint8_t clientNumber, JsonDocument& request) {
  JsonDocument response;
  beginResponse(response, request, "GetMsaDeviceInfo", "success");
  JsonObject payload = response["payload"].to<JsonObject>();

  if (msaInstalled) {
    payload["serialNumber"] = MSA_SERIAL_NUMBER;
    payload["modelNumber"] = MSA_MODEL_NUMBER;
    payload["firmwareVersion"] = MSA_FIRMWARE_VERSION;
    payload["firstBootDate"] = MSA_FIRST_BOOT_DATE;
    payload["dateOfManufacture"] = MSA_MANUFACTURE_DATE;
  } else {
    // M21 explicitly requires all five fields with null values.
    payload["serialNumber"] = nullptr;
    payload["modelNumber"] = nullptr;
    payload["firmwareVersion"] = nullptr;
    payload["firstBootDate"] = nullptr;
    payload["dateOfManufacture"] = nullptr;
  }

  sendWebSocketJson(clientNumber, response);
}

void handleGetMsaMeasurements(uint8_t clientNumber, JsonDocument& request) {
  JsonDocument response;
  beginResponse(response, request, "GetMsaMeasurements", "success");
  JsonObject payload = response["payload"].to<JsonObject>();

  if (msaInstalled) {
    payload["gridL1L2Voltage"] = simulatedMsaGridL1L2Voltage();
    payload["gridL1Current"] = simulatedMsaGridL1Current();
    payload["gridL2Current"] = simulatedMsaGridL2Current();
    payload["loadL1L2Voltage"] = simulatedMsaLoadL1L2Voltage();
  } else {
    // M22 requires all four fields and uses null when no MSA is connected.
    payload["gridL1L2Voltage"] = nullptr;
    payload["gridL1Current"] = nullptr;
    payload["gridL2Current"] = nullptr;
    payload["loadL1L2Voltage"] = nullptr;
  }

  sendWebSocketJson(clientNumber, response);
}

void handleGetMsaFaults(uint8_t clientNumber, JsonDocument& request) {
  JsonDocument response;
  beginResponse(response, request, "GetMsaFaults", "success");
  JsonObject payload = response["payload"].to<JsonObject>();

  if (activeMsaFaultCode.isEmpty()) {
    payload["faultCode"] = nullptr;
    payload["faultTime"] = nullptr;
  } else {
    payload["faultCode"] = activeMsaFaultCode;
    payload["faultTime"] = activeMsaFaultTime;
  }

  JsonArray history = payload["faultHistory"].to<JsonArray>();

  for (size_t i = 0; i < msaFaultHistoryCount; ++i) {
    JsonObject entry = history.add<JsonObject>();
    entry["faultCode"] = msaFaultHistory[i].faultCode;
    entry["faultTime"] = msaFaultHistory[i].faultTime;
    entry["state"] = msaFaultHistory[i].state;
  }

  sendWebSocketJson(clientNumber, response);
}

void handleGetSystemLog(uint8_t clientNumber, JsonDocument& request) {
  JsonDocument response;
  beginResponse(response, request, "GetSystemLog", "success");
  JsonObject payload = response["payload"].to<JsonObject>();
  JsonArray entries = payload["entries"].to<JsonArray>();

  for (size_t i = 0; i < systemLogEntryCount; ++i) {
    JsonObject entry = entries.add<JsonObject>();
    entry["time"] = systemLogEntries[i].time;
    entry["message"] = systemLogEntries[i].message;
  }

  sendWebSocketJson(clientNumber, response);
}

void handleSetReferenceValue(
  uint8_t clientNumber,
  JsonDocument& request,
  JsonObjectConst requestPayload
) {
  JsonArrayConst requestedValues =
    requestPayload["values"].as<JsonArrayConst>();

  if (requestPayload.isNull() || requestedValues.isNull() ||
      requestedValues.size() == 0 ||
      requestedValues.size() > MAX_REFERENCE_VALUES) {
    sendWebSocketError(
      clientNumber,
      request,
      "SetReferenceValue",
      "INVALID_REQUEST",
      "values must be a non-empty array within the storage profile limit."
    );
    return;
  }

  ReferenceValueRecord stagedValues[MAX_REFERENCE_VALUES];
  size_t stagedCount = referenceValueCount;

  for (size_t i = 0; i < referenceValueCount; ++i) {
    stagedValues[i] = referenceValues[i];
  }

  String requestKeys[MAX_REFERENCE_VALUES];
  size_t requestKeyCount = 0;

  for (JsonVariantConst requestedVariant : requestedValues) {
    JsonObjectConst requestedValue = requestedVariant.as<JsonObjectConst>();

    if (requestedValue.isNull() ||
        !requestedValue["key"].is<const char*>() ||
        !requestedValue["type"].is<const char*>() ||
        !requestedValue.containsKey("value")) {
      sendWebSocketError(
        clientNumber,
        request,
        "SetReferenceValue",
        "INVALID_REQUEST",
        "Each value requires key, type, and a scalar value."
      );
      return;
    }

    const char* key = requestedValue["key"].as<const char*>();
    const char* type = requestedValue["type"].as<const char*>();

    if (key == nullptr || strlen(key) == 0 ||
        strlen(key) > MAX_REFERENCE_KEY_LENGTH) {
      sendWebSocketError(
        clientNumber,
        request,
        "SetReferenceValue",
        "INVALID_REQUEST",
        "Reference keys must be non-empty and within the profile limit."
      );
      return;
    }

    for (size_t i = 0; i < requestKeyCount; ++i) {
      if (requestKeys[i] == key) {
        sendWebSocketError(
          clientNumber,
          request,
          "SetReferenceValue",
          "INVALID_REQUEST",
          "Duplicate reference keys are not allowed in one request."
        );
        return;
      }
    }

    requestKeys[requestKeyCount++] = key;
    ReferenceValueRecord validatedRecord;

    if (!assignReferenceValue(
          validatedRecord,
          key,
          type,
          requestedValue["value"]
        )) {
      sendWebSocketError(
        clientNumber,
        request,
        "SetReferenceValue",
        "INVALID_REQUEST",
        "Unsupported type, type/value mismatch, null, or oversized value."
      );
      return;
    }

    int existingIndex =
      findReferenceValueIndex(stagedValues, stagedCount, key);

    if (existingIndex >= 0) {
      stagedValues[existingIndex] = validatedRecord;
    } else {
      if (stagedCount >= MAX_REFERENCE_VALUES) {
        sendWebSocketError(
          clientNumber,
          request,
          "SetReferenceValue",
          "INVALID_REQUEST",
          "The reference-value storage limit would be exceeded."
        );
        return;
      }

      stagedValues[stagedCount++] = validatedRecord;
    }
  }

  String serialized;

  if (!serializeReferenceValueSet(stagedValues, stagedCount, serialized)) {
    sendWebSocketError(
      clientNumber,
      request,
      "SetReferenceValue",
      "INVALID_REQUEST",
      "The reference-value storage limit would be exceeded."
    );
    return;
  }

  // Persist the complete staged set before changing runtime state. This makes
  // M25 an atomic upsert: either every entry is stored or none are changed.
  if (!persistReferenceValueSet(stagedValues, stagedCount)) {
    sendWebSocketError(
      clientNumber,
      request,
      "SetReferenceValue",
      "REQUEST_FAILED",
      "The reference values could not be persisted."
    );
    return;
  }

  for (size_t i = 0; i < stagedCount; ++i) {
    referenceValues[i] = stagedValues[i];
  }

  for (size_t i = stagedCount; i < referenceValueCount; ++i) {
    referenceValues[i] = ReferenceValueRecord();
  }

  referenceValueCount = stagedCount;
  addSystemLog("Installer reference values updated");
  sendWebSocketAcknowledgement(clientNumber, request, "SetReferenceValue");
}

void handleGetReferenceValue(
  uint8_t clientNumber,
  JsonDocument& request,
  JsonObjectConst requestPayload
) {
  JsonArrayConst requestedKeys = requestPayload["keys"].as<JsonArrayConst>();

  if (requestPayload.isNull() || requestedKeys.isNull() ||
      requestedKeys.size() == 0 ||
      requestedKeys.size() > MAX_REFERENCE_VALUES) {
    sendWebSocketError(
      clientNumber,
      request,
      "GetReferenceValue",
      "INVALID_REQUEST",
      "keys must be a non-empty array within the storage profile limit."
    );
    return;
  }

  int resolvedIndexes[MAX_REFERENCE_VALUES];
  String seenKeys[MAX_REFERENCE_VALUES];
  size_t resolvedCount = 0;

  for (JsonVariantConst keyVariant : requestedKeys) {
    if (!keyVariant.is<const char*>()) {
      sendWebSocketError(
        clientNumber,
        request,
        "GetReferenceValue",
        "INVALID_REQUEST",
        "Every requested key must be a non-empty string."
      );
      return;
    }

    const char* key = keyVariant.as<const char*>();

    if (key == nullptr || strlen(key) == 0 ||
        strlen(key) > MAX_REFERENCE_KEY_LENGTH) {
      sendWebSocketError(
        clientNumber,
        request,
        "GetReferenceValue",
        "INVALID_REQUEST",
        "Every requested key must be a non-empty string."
      );
      return;
    }

    for (size_t i = 0; i < resolvedCount; ++i) {
      if (seenKeys[i] == key) {
        sendWebSocketError(
          clientNumber,
          request,
          "GetReferenceValue",
          "INVALID_REQUEST",
          "Duplicate requested keys are not allowed."
        );
        return;
      }
    }

    int index =
      findReferenceValueIndex(referenceValues, referenceValueCount, key);

    if (index < 0) {
      sendWebSocketError(
        clientNumber,
        request,
        "GetReferenceValue",
        "INVALID_REQUEST",
        "A requested reference key is not stored."
      );
      return;
    }

    seenKeys[resolvedCount] = key;
    resolvedIndexes[resolvedCount++] = index;
  }

  JsonDocument response;
  beginResponse(response, request, "GetReferenceValue", "success");
  JsonObject payload = response["payload"].to<JsonObject>();
  JsonArray values = payload["values"].to<JsonArray>();

  for (size_t i = 0; i < resolvedCount; ++i) {
    JsonObject value = values.add<JsonObject>();
    addReferenceValueToJson(value, referenceValues[resolvedIndexes[i]]);
  }

  sendWebSocketJson(clientNumber, response);
}

// =====================================================
// WebSocket dispatcher
// =====================================================

void processWebSocketRequest(
  uint8_t clientNumber,
  uint8_t* rawPayload,
  size_t payloadLength
) {
  JsonDocument request;
  DeserializationError error =
    deserializeJson(request, rawPayload, payloadLength);

  if (error) {
    JsonDocument emptyRequest;
    sendWebSocketError(
      clientNumber,
      emptyRequest,
      "ProtocolError",
      "INVALID_REQUEST",
      "Malformed JSON request."
    );
    return;
  }

  if (!request.is<JsonObject>()) {
    sendWebSocketError(
      clientNumber,
      request,
      "ProtocolError",
      "INVALID_REQUEST",
      "The WebSocket message must be a JSON object."
    );
    return;
  }

  const char* name = request["name"];

  if (name == nullptr || strlen(name) == 0) {
    sendWebSocketError(
      clientNumber,
      request,
      "ProtocolError",
      "INVALID_REQUEST",
      "Missing name field."
    );
    return;
  }

  const char* messageType = request["messageType"] | "Request";
  bool commissionUpdate = strcmp(name, "UpdateCommissionRecordFlag") == 0;

  if (commissionUpdate) {
    if (strcmp(messageType, "Event") != 0) {
      sendWebSocketError(
        clientNumber,
        request,
        name,
        "INVALID_REQUEST",
        "UpdateCommissionRecordFlag must use messageType Event."
      );
      return;
    }
  } else if (strcmp(messageType, "Request") != 0) {
    sendWebSocketError(
      clientNumber,
      request,
      name,
      "INVALID_REQUEST",
      "This command must use messageType Request."
    );
    return;
  }

  JsonObjectConst requestPayload = request["payload"].as<JsonObjectConst>();

  if (strcmp(name, "GetFirmwareUpdateStatus") == 0) {
    handleGetFirmwareUpdateStatus(clientNumber, request, requestPayload);
  } else if (strcmp(name, "SetTimeConfig") == 0) {
    handleSetTimeConfig(clientNumber, request, requestPayload);
  } else if (strcmp(name, "GetTimeConfig") == 0) {
    handleGetTimeConfig(clientNumber, request);
  } else if (strcmp(name, "SetCommissioningSettings") == 0) {
    handleSetCommissioningSettings(clientNumber, request, requestPayload);
  } else if (strcmp(name, "GetCommissioningSettings") == 0) {
    handleGetCommissioningSettings(clientNumber, request);
  } else if (strcmp(name, "GetCtClampStatus") == 0) {
    handleGetCtClampStatus(clientNumber, request);
  } else if (strcmp(name, "SetBackupEnable") == 0) {
    handleSetBackupEnable(clientNumber, request, requestPayload);
  } else if (strcmp(name, "GetBackupEnable") == 0) {
    handleGetBackupEnable(clientNumber, request);
  } else if (strcmp(name, "CheckMsaInstall") == 0) {
    handleCheckMsaInstall(clientNumber, request);
  } else if (strcmp(name, "SystemCommand") == 0) {
    handleSystemCommand(clientNumber, request, requestPayload);
  } else if (strcmp(name, "GetCommissionRecordFlag") == 0) {
    handleGetCommissionRecordFlag(clientNumber, request);
  } else if (strcmp(name, "UpdateCommissionRecordFlag") == 0) {
    handleUpdateCommissionRecordFlag(clientNumber, request, requestPayload);
  } else if (strcmp(name, "GetBdcDeviceInfo") == 0) {
    handleGetBdcDeviceInfo(clientNumber, request);
  } else if (strcmp(name, "GetNetworkStatus") == 0) {
    handleGetNetworkStatus(clientNumber, request);
  } else if (strcmp(name, "GetVehicleStatus") == 0) {
    handleGetVehicleStatus(clientNumber, request);
  } else if (strcmp(name, "GetPowerMeasurements") == 0) {
    handleGetPowerMeasurements(clientNumber, request);
  } else if (strcmp(name, "GetChargeEventLog") == 0) {
    handleGetChargeEventLog(clientNumber, request);
  } else if (strcmp(name, "GetFaults") == 0) {
    handleGetFaults(clientNumber, request);
  } else if (strcmp(name, "GetLifetimeMetrics") == 0) {
    handleGetLifetimeMetrics(clientNumber, request);
  } else if (strcmp(name, "GetV2hDeviceInfo") == 0) {
    handleGetV2hDeviceInfo(clientNumber, request);
  } else if (strcmp(name, "GetV2hMeasurements") == 0) {
    handleGetV2hMeasurements(clientNumber, request);
  } else if (strcmp(name, "GetBackupEventLog") == 0) {
    handleGetBackupEventLog(clientNumber, request);
  } else if (strcmp(name, "GetCtMeasurements") == 0) {
    handleGetCtMeasurements(clientNumber, request);
  } else if (strcmp(name, "GetMsaDeviceInfo") == 0) {
    handleGetMsaDeviceInfo(clientNumber, request);
  } else if (strcmp(name, "GetMsaMeasurements") == 0) {
    handleGetMsaMeasurements(clientNumber, request);
  } else if (strcmp(name, "GetMsaFaults") == 0) {
    handleGetMsaFaults(clientNumber, request);
  } else if (strcmp(name, "GetSystemLog") == 0) {
    handleGetSystemLog(clientNumber, request);
  } else if (strcmp(name, "SetReferenceValue") == 0) {
    handleSetReferenceValue(clientNumber, request, requestPayload);
  } else if (strcmp(name, "GetReferenceValue") == 0) {
    handleGetReferenceValue(clientNumber, request, requestPayload);
  } else {
    sendWebSocketError(
      clientNumber,
      request,
      name,
      "INVALID_REQUEST",
      "Unknown WebSocket request name."
    );
  }
}

void webSocketEvent(
  uint8_t clientNumber,
  WStype_t eventType,
  uint8_t* payload,
  size_t length
) {
  switch (eventType) {
    case WStype_CONNECTED: {
      if (activeWebSocketClients < UINT8_MAX) {
        ++activeWebSocketClients;
      }

      IPAddress remoteIp = webSocket.remoteIP(clientNumber);
      Serial.print("WebSocket client connected: ");
      Serial.print(remoteIp);
      Serial.print(" path=");
      Serial.println(reinterpret_cast<const char*>(payload));
      addSystemLog("Installer WebSocket connected");
      break;
    }

    case WStype_DISCONNECTED:
      if (activeWebSocketClients > 0) {
        --activeWebSocketClients;
      }

      Serial.print("WebSocket client disconnected: ");
      Serial.println(clientNumber);
      addSystemLog("Installer WebSocket disconnected");
      break;

    case WStype_TEXT:
      Serial.print("WS RX[");
      Serial.print(clientNumber);
      Serial.print("]: ");
      Serial.write(payload, length);
      Serial.println();
      processWebSocketRequest(clientNumber, payload, length);
      break;

    case WStype_BIN: {
      JsonDocument emptyRequest;
      sendWebSocketError(
        clientNumber,
        emptyRequest,
        "ProtocolError",
        "INVALID_REQUEST",
        "Binary WebSocket messages are not supported."
      );
      break;
    }

    default:
      break;
  }
}

// =====================================================
// BLE callbacks and initialization
// =====================================================

class CommandCallbacks : public NimBLECharacteristicCallbacks {
  void onWrite(
    NimBLECharacteristic* characteristic,
    NimBLEConnInfo& connectionInfo
  ) override {
    std::string value = characteristic->getValue();

    if (value.empty()) {
      sendSimpleBleResponse("ERROR", "FAILED", "Empty command");
      return;
    }

    processBleCommand(value, connectionInfo);
  }
};

class ResponseCallbacks : public NimBLECharacteristicCallbacks {
  void onSubscribe(
    NimBLECharacteristic* characteristic,
    NimBLEConnInfo& connectionInfo,
    uint16_t subscriptionValue
  ) override {
    responseNotificationsEnabled =
      subscriptionValue == 1 || subscriptionValue == 3;

    Serial.print("Notifications: ");
    Serial.println(responseNotificationsEnabled ? "ENABLED" : "DISABLED");
  }
};

class ServerCallbacks : public NimBLEServerCallbacks {
  void onConnect(
    NimBLEServer* server,
    NimBLEConnInfo& connectionInfo
  ) override {
    bleClientConnected = true;
    bleConnectionEncrypted = connectionInfo.isEncrypted();

    Serial.println();
    Serial.println("BLE client connected");
    Serial.print("Client: ");
    Serial.println(connectionInfo.getAddress().toString().c_str());
  }

  void onDisconnect(
    NimBLEServer* server,
    NimBLEConnInfo& connectionInfo,
    int reason
  ) override {
    bleClientConnected = false;
    bleConnectionEncrypted = false;
    responseNotificationsEnabled = false;

    Serial.print("BLE client disconnected. Reason: ");
    Serial.println(reason);
    delay(200);
    NimBLEDevice::startAdvertising();
    Serial.println("BLE advertising restarted");
  }

  uint32_t onPassKeyDisplay() override {
    Serial.print("Enter this BLE passkey: ");
    Serial.println(BLE_PASSKEY);
    return BLE_PASSKEY;
  }

  void onAuthenticationComplete(NimBLEConnInfo& connectionInfo) override {
    bleConnectionEncrypted = connectionInfo.isEncrypted();

    Serial.println();
    Serial.println("BLE authentication completed");
    Serial.print("Encrypted: ");
    Serial.println(connectionInfo.isEncrypted() ? "YES" : "NO");
    Serial.print("Bonded: ");
    Serial.println(connectionInfo.isBonded() ? "YES" : "NO");
  }
};

void startBle() {
  NimBLEDevice::init(DEVICE_NAME);

  NimBLEDevice::setSecurityAuth(
    true,  // bonding
    true,  // MITM protection
    true   // secure connections
  );

  NimBLEDevice::setSecurityIOCap(BLE_HS_IO_DISPLAY_ONLY);
  NimBLEDevice::setSecurityPasskey(BLE_PASSKEY);

  bleServer = NimBLEDevice::createServer();
  bleServer->setCallbacks(new ServerCallbacks());

  NimBLEService* service = bleServer->createService(SERVICE_UUID);

  commandCharacteristic = service->createCharacteristic(
    COMMAND_UUID,
    NIMBLE_PROPERTY::WRITE | NIMBLE_PROPERTY::WRITE_ENC
  );

  responseCharacteristic = service->createCharacteristic(
    RESPONSE_UUID,
    NIMBLE_PROPERTY::READ |
      NIMBLE_PROPERTY::NOTIFY |
      NIMBLE_PROPERTY::READ_ENC
  );

  commandCharacteristic->setCallbacks(new CommandCallbacks());
  responseCharacteristic->setCallbacks(new ResponseCallbacks());
  responseCharacteristic->setValue(
    "{\"cmd\":\"DEVICE_STATUS\",\"status\":\"READY\"}"
  );

  service->start();

  bleAdvertising = NimBLEDevice::getAdvertising();
  bleAdvertising->clearData();
  bleAdvertising->enableScanResponse(true);
  bleAdvertising->addServiceUUID(SERVICE_UUID);
  bleAdvertising->setName(DEVICE_NAME);
  bleAdvertising->start();

  Serial.println("BLE advertising started");
  Serial.print("Device name: ");
  Serial.println(DEVICE_NAME);
}

// =====================================================
// Background processing
// =====================================================

void updateLifetimeMetrics() {
  unsigned long now = millis();

  if (lastMetricsUpdateMs == 0) {
    lastMetricsUpdateMs = now;
    lastMetricsSaveMs = now;
    return;
  }

  unsigned long elapsedMs = now - lastMetricsUpdateMs;

  if (elapsedMs < 1000) {
    return;
  }

  double elapsedHours = elapsedMs / 3600000.0;

  // Simulator defaults to a charging state at approximately 7.68 kW.
  lifetimeMetrics.chargingHours += elapsedHours;
  lifetimeMetrics.energyChargedKwh += 7.68 * elapsedHours;
  lastMetricsUpdateMs = now;

  if (now - lastMetricsSaveMs >= METRICS_SAVE_INTERVAL_MS) {
    saveLifetimeMetrics();
    lastMetricsSaveMs = now;
  }
}

void processPendingSystemAction() {
  if (pendingSystemAction == PendingSystemAction::None ||
      millis() - pendingSystemActionAtMs < SYSTEM_ACTION_DELAY_MS) {
    return;
  }

  PendingSystemAction action = pendingSystemAction;
  pendingSystemAction = PendingSystemAction::None;

  if (action == PendingSystemAction::EraseCustomerData) {
    resetChargerConfigurationToDefaults();
    initializeSampleFaults();
    initializeMsaFaults();
    addSystemLog("Customer configuration erased");
    Serial.println("Customer configuration erased");
    return;
  }

  if (action == PendingSystemAction::FactoryReset) {
    addSystemLog("Factory reset requested");
    resetChargerConfigurationToDefaults();
    clearReferenceValues();
    clearWifiCredentials();
    NimBLEDevice::deleteAllBonds();
    delay(100);
    ESP.restart();
    return;
  }

  if (action == PendingSystemAction::RemoteReboot) {
    addSystemLog("Remote reboot requested");
    saveLifetimeMetrics();
    delay(100);
    ESP.restart();
  }
}

// =====================================================
// Arduino setup and loop
// =====================================================

void setup() {
  Serial.begin(115200);
  delay(1500);

  Serial.println();
  Serial.println("==============================================");
  Serial.println("EV Charger BLE + SoftAP WebSocket M01-M25");
  Serial.println("==============================================");

  initializeSystemLog();
  loadPersistentState();
  loadReferenceValues();
  initializeSampleFaults();
  initializeMsaFaults();
  webSocket.onEvent(webSocketEvent);
  startSoftApAndWebSocket();
  startBle();
  addSystemLog("BDC startup complete");

  String storedSsid;
  String storedPassword;

  if (loadWifiCredentials(storedSsid, storedPassword)) {
    Serial.println("Stored Wi-Fi configuration found; reconnecting");
    startWifiConnection(storedSsid, storedPassword, false, true);
    storedPassword = "";
  } else {
    Serial.println("No stored Wi-Fi configuration; use encrypted BLE provisioning");
  }
}

void loop() {
  webSocket.loop();
  processWifiConnection();
  updateLifetimeMetrics();
  processPendingSystemAction();
  delay(5);
}
