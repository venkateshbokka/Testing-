# EV Charger BLE + SoftAP WebSocket (M01-M25 + BLE B01-B05)

This Arduino project extends the original `EV_SIM_001` code with the complete
M01-M25 WebSocket protocol and the B01-B05 BLE provisioning flow.

## What is implemented

- BLE pairing/bonding with passkey `123456`
- Encrypted BLE command and response characteristics
- Wi-Fi credential save, load, clear, reconnect, and station IP notification
- Simultaneous station + SoftAP (`WIFI_AP_STA`) operation
- WebSocket server on the SoftAP
- Standard request/response/event message envelope
- JSON validation and the four standardized WebSocket error categories
- Preferences persistence for time zone, commissioning settings, backup state,
  commissioning flags, Wi-Fi credentials, and lifetime metrics
- Delayed reboot/factory-reset processing so the WebSocket acknowledgement is
  sent first
- `FirmwareUpdateStatus`, `FaultEvent`, and `MsaFaultEvent` helpers
- Typed, atomic M25 reference-value storage in Preferences
- Bounded 100-entry system log and MSA measurement/fault simulation
- All M01-M25 request handlers and BLE B01-B05 logical operations

## Arduino IDE requirements

Install these through **Tools > Manage Libraries**:

1. **NimBLE-Arduino** 2.x
2. **ArduinoJson** 7.x
3. **WebSockets** by Markus Sattler (Links2004)

Install the Espressif ESP32 board package and select your ESP32-S3 board, for
example **ESP32S3 Dev Module**. This sketch uses the callback signatures from
NimBLE-Arduino 2.x and the elastic `JsonDocument` API from ArduinoJson 7.x.

## Open and upload

1. Open `EV_Charger_M01_M21.ino` in Arduino IDE.
2. Select the correct ESP32-S3 board and COM port.
3. Compile and upload.
4. Open Serial Monitor at `115200` baud.

## Connection flow

1. Pair the mobile app with BLE device `EV_SIM_001` using PIN `123456`.
2. Enable notifications on response characteristic
   `12345678-1234-1234-1234-123456789002`.
3. Write Wi-Fi credentials to command characteristic
   `12345678-1234-1234-1234-123456789001`.
4. The BLE success response returns station IP, SoftAP IP, and WebSocket URL.
5. Connect the phone to SoftAP `EV_SIM_001_SETUP` with password `EVSim123!`.
6. Open WebSocket `ws://192.168.4.1:81/`.
7. Send the full M01-M25 JSON messages defined in `websocketsesp32.docx`.

`websocket_test_requests.json` contains one ready-to-send request for every
implemented incoming command. Send its array elements one at a time.
`ble_test_requests.json` contains the four Installer App BLE operations. B04,
`FW_UPDATE_STATUS`, is an unsolicited charger notification rather than a
request.

The SoftAP remains active while the station interface joins the customer's
Wi-Fi. This prevents the installer app from losing its WebSocket connection.

## BLE provisioning examples

The supplier-style BLE operations use `operation` and uppercase status values.
For this simulator they are transported as JSON over the encrypted command and
response characteristics because the separate production characteristic
mapping/profile was not supplied.

Check configuration (B01):

```json
{"operation":"WIFI_CONFIG_CHECK"}
```

Write and atomically persist credentials (B02):

```json
{
  "operation": "WIFI_CREDENTIALS_WRITE",
  "ssid": "YourWiFi",
  "password": "YourPassword",
  "security_type": "WPA2"
}
```

Read BDC/V2H firmware state (B03):

```json
{"operation":"FW_STATUS_CHECK"}
```

Enable/inspect the SoftAP handoff (B05):

```json
{"operation":"SOFTAP_ENABLE"}
```

The older `cmd` messages (`WIFI_CONFIG_CHECK`, `WIFI_CREDENTIALS_WRITE`,
`GET_IP_ADDRESS`, `WIFI_CONFIG_CLEAR`, and `PING`) remain available for
backward compatibility with the existing mobile application.

## WebSocket example

Request:

```json
{
  "messageId": "a1b2c3d4-0013-4a1b-8c2d-000000010013",
  "messageType": "Request",
  "name": "GetPowerMeasurements",
  "timestamp": "2026-06-24T16:52:59Z",
  "source": "InstallerApp",
  "destination": "Charger",
  "status": "",
  "payload": {}
}
```

Response:

```json
{
  "messageId": "a1b2c3d4-0013-4a1b-8c2d-000000010013",
  "messageType": "Response",
  "name": "GetPowerMeasurements",
  "timestamp": "2026-06-24T16:53:00Z",
  "source": "Charger",
  "destination": "InstallerApp",
  "status": "success",
  "payload": {
    "chargeCurrentL1L2": {"L1": 16.0, "L2": 16.0},
    "dischargeCurrentL1L2": {"L1": 0.0, "L2": 0.0},
    "voltageL1L2": 240.1,
    "status": "Charging",
    "state": {
      "code": "CHARGING",
      "description": "Actively charging the vehicle."
    }
  }
}
```

## Implemented command map

| Module | Incoming command(s) | Outbound event |
|---|---|---|
| M01 | `GetFirmwareUpdateStatus` | `FirmwareUpdateStatus` |
| M02 | `SetTimeConfig`, `GetTimeConfig` | - |
| M03 | `SetCommissioningSettings` | - |
| M04 | `GetCommissioningSettings` | - |
| M05 | `GetCtClampStatus` | - |
| M06 | `SetBackupEnable`, `GetBackupEnable` | - |
| M07 | `CheckMsaInstall` | - |
| M08 | `SystemCommand` | - |
| M09 | `GetCommissionRecordFlag`, `UpdateCommissionRecordFlag` | - |
| M10 | `GetBdcDeviceInfo` | - |
| M11 | `GetNetworkStatus` | - |
| M12 | `GetVehicleStatus` | - |
| M13 | `GetPowerMeasurements` | - |
| M14 | `GetChargeEventLog` | - |
| M15 | `GetFaults` | `FaultEvent` |
| M16 | `GetLifetimeMetrics` | - |
| M17 | `GetV2hDeviceInfo` | - |
| M18 | `GetV2hMeasurements` | - |
| M19 | `GetBackupEventLog` | - |
| M20 | `GetCtMeasurements` | - |
| M21 | `GetMsaDeviceInfo` | - |
| M22 | `GetMsaMeasurements` | - |
| M23 | `GetMsaFaults` | `MsaFaultEvent` |
| M24 | `GetSystemLog` | - |
| M25 | `SetReferenceValue`, `GetReferenceValue` | - |

## Functions to connect to real hardware

The project is complete as a simulator. The following data is intentionally
sampled because no GPIO, ADC, CAN, Modbus, V2H, MSA, or OTA hardware interface
was provided:

- CT and power readings: `simulatedCtL1Current()`,
  `simulatedCtL2Current()`, `simulatedChargeCurrentL1()`, and
  `simulatedChargeCurrentL2()`
- BDC/V2H/MSA identity constants at the top of the sketch
- Vehicle state and V2H measurements in their respective handlers
- MSA measurements in `simulatedMsaGridL1L2Voltage()`,
  `simulatedMsaGridL1Current()`, `simulatedMsaGridL2Current()`, and
  `simulatedMsaLoadL1L2Voltage()`
- Charge and backup event arrays
- Initial BDC fault records and the in-memory MSA fault history

Connect actual firmware/hardware logic to these public helpers:

```cpp
setFirmwareUpdateStatus("BDC", "Downloading");
setFirmwareUpdateStatus("BDC", "Downloaded");
setFirmwareUpdateStatus("BDC", "Installing");
setFirmwareUpdateStatus("BDC", "InstallationComplete");

reportFaultTransition(
  "1",
  "BDC cannot turn off power mechanically",
  "Active"
);

reportMsaFaultTransition("MSA-F301", "raised");
reportMsaFaultTransition("MSA-F301", "cleared");
```

Firmware progress is status-only, exactly as M01 specifies; the event never
sends a numeric percentage.

## Important production notes

- The WebSocket is local plaintext (`ws://`) and is protected only by the
  WPA2 SoftAP password. Use `wss://` or application authentication if the
  production security design requires it.
- `GetNetworkStatus` currently treats a connected station link as Internet
  connectivity. Replace that line with the charger's real Internet health
  check.
- System logs, BDC faults, and MSA fault history are RAM/sample data. Reference
  values, Wi-Fi configuration, charger settings, and lifetime metrics use
  Preferences and survive reboot. `eraseCustomerData` retains M25 reference
  values; `factoryReset` clears them and deletes BLE bonds.
- Never print or return the customer's Wi-Fi password. This project clears its
  temporary RAM copy after each connection attempt.
