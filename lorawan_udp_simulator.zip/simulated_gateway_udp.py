import socket, json, time, base64
from datetime import datetime

with open("config_gateway.json") as f:
    config = json.load(f)

GATEWAY_EUI = bytes.fromhex(config["gateway_eui"])
TTS_ADDRESS = config["tts_address"]
TTS_PORT = config["port"]

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind(("", 1700))

def send_pull_data():
    token = b"\x00\x01"
    packet = b"\x02" + token + b"\x02" + GATEWAY_EUI
    sock.sendto(packet, (TTS_ADDRESS, TTS_PORT))
    print("[GW] Sent PULL_DATA")

def forward_packet(payload_b64):
    token = b"\x00\x02"
    json_payload = json.dumps({
        "rxpk": [{
            "tmst": int(time.time() * 1e6),
            "freq": config["frequency"] / 1e6,
            "chan": 0,
            "rfch": 0,
            "stat": 1,
            "modu": "LORA",
            "datr": "SF7BW125",
            "codr": "4/5",
            "rssi": -30,
            "lsnr": 5.5,
            "size": len(base64.b64decode(payload_b64)),
            "data": payload_b64
        }]
    }).encode()
    packet = b"\x02" + token + b"\x00" + GATEWAY_EUI + json_payload
    sock.sendto(packet, (TTS_ADDRESS, TTS_PORT))
    print("[GW] Forwarded RXPK to TTS")

send_pull_data()