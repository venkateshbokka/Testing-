import json, base64
from lorawan_utils import aes_encrypt, calculate_mic
from simulated_gateway_udp import forward_packet

with open("config_device.json") as f:
    config = json.load(f)

deveui = bytes.fromhex(config["deveui"])[::-1]
appeui = bytes.fromhex(config["appeui"])[::-1]
devnonce = bytes.fromhex(config["devnonce"])[::-1]
appkey = bytes.fromhex(config["appkey"])

mhdr = b"\x00"
join_payload = appeui + deveui + devnonce
mic = calculate_mic(join_payload, appkey, b"\x00" * 16)[:4]
packet = mhdr + join_payload + mic
encoded = base64.b64encode(packet).decode()

print("[Device] Sending JoinRequest:", encoded)
forward_packet(encoded)