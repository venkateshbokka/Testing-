import hashlib, hmac
from Crypto.Cipher import AES

def aes_encrypt(key: bytes, data: bytes) -> bytes:
    cipher = AES.new(key, AES.MODE_ECB)
    return cipher.encrypt(data)

def calculate_mic(msg: bytes, key: bytes, b0: bytes) -> bytes:
    cmac = hmac.new(key, b0 + msg, hashlib.sha256).digest()
    return cmac[:4]

def derive_session_keys(appkey: bytes, appnonce: bytes, netid: bytes, devnonce: bytes):
    nwk_skey = aes_encrypt(appkey, b'\x01' + appnonce + netid + devnonce + b'\x00' * 7)
    app_skey = aes_encrypt(appkey, b'\x02' + appnonce + netid + devnonce + b'\x00' * 7)
    return nwk_skey, app_skey