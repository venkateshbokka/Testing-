import socket
import time
import base64
import struct
import os
import json
from Crypto.Cipher import AES

with open("device_config.json") as f:
    config = json.load(f)

APP_EUI = bytes.fromhex(config["app_eui"])[::-1]
DEV_EUI = bytes.fromhex(config["dev_eui"])[::-1]
APP_KEY = bytes.fromhex(config["app_key"])
DEVICE_ADDR = config["dev_addr"]
UDP_IP = config["gateway_ip"]
UDP_PORT = config["gateway_port"]
DEVICE_PORT = config["device_listen_port"]

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind(("0.0.0.0", DEVICE_PORT))

def build_join_request():
    MHDR = b'\x00'
    DevNonce = os.urandom(2)
    payload = APP_EUI + DEV_EUI + DevNonce
    mic = b'\x00\x00\x00\x00'
    return MHDR + payload + mic

def send_join():
    phy_payload = build_join_request()
    rxpk = {
        "rxpk": [{
            "time": time.strftime('%Y-%m-%dT%H:%M:%SZ'),
            "tmst": 123456,
            "freq": 868.1,
            "chan": 0,
            "rfch": 0,
            "stat": 1,
            "modu": "LORA",
            "datr": "SF7BW125",
            "codr": "4/5",
            "rssi": -42,
            "lsnr": 5.5,
            "size": len(phy_payload),
            "data": base64.b64encode(phy_payload).decode()
        }]
    }
    header = struct.pack("!B B H", 2, 0x00, 0x0001) + os.urandom(8) + b'\x00'
    pkt = header + json.dumps(rxpk).encode()
    sock.sendto(pkt, (UDP_IP, UDP_PORT))
    print("[Device] Join Request Sent")

def listen_for_accept():
    print("[Device] Waiting for Join Accept...")
    data, _ = sock.recvfrom(2048)
    if data[3] == 0x03:
        print("[Device] Join Accept Received!")

def send_temp(temp_val):
    MHDR = b'\x40'
    DevAddr = bytes.fromhex(DEVICE_ADDR)[::-1]
    FCtrl = b'\x00'
    FCnt = b'\x00\x01'
    FPort = b'\x01'
    payload = struct.pack("f", temp_val)
    msg = MHDR + DevAddr + FCtrl + FCnt + FPort + payload + b'\x00\x00\x00\x00'

    rxpk = {
        "rxpk": [{
            "time": time.strftime('%Y-%m-%dT%H:%M:%SZ'),
            "tmst": 123457,
            "freq": 868.1,
            "chan": 0,
            "rfch": 0,
            "stat": 1,
            "modu": "LORA",
            "datr": "SF7BW125",
            "codr": "4/5",
            "rssi": -42,
            "lsnr": 5.2,
            "size": len(msg),
            "data": base64.b64encode(msg).decode()
        }]
    }

    header = struct.pack("!B B H", 2, 0x00, 0x0001) + os.urandom(8) + b'\x00'
    pkt = header + json.dumps(rxpk).encode()
    sock.sendto(pkt, (UDP_IP, UDP_PORT))
    print(f"[Device] Uplink Temperature Sent: {temp_val}°C")

send_join()
listen_for_accept()
time.sleep(2)
send_temp(27.6)
