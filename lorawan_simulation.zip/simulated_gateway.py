import socket
import json
import time

with open("station_config.json") as f:
    config = json.load(f)

GATEWAY_EUI = config["gateway_eui"]
TTS_ADDRESS = (config["ttn_address"], config["ttn_port"])
LOCAL_UDP_PORT = config["listen_port"]

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind(("0.0.0.0", LOCAL_UDP_PORT))

print("[Gateway] Listening on port", LOCAL_UDP_PORT)

def forward_to_tts(data):
    sock.sendto(data, TTS_ADDRESS)

def forward_to_device(data):
    sock.sendto(data, ("127.0.0.1", 1701))

while True:
    data, addr = sock.recvfrom(2048)
    msg_type = data[3]

    if msg_type == 0x00:
        print("[Gateway] PUSH_DATA -> TTS")
        forward_to_tts(data)
    elif msg_type == 0x02:
        print("[Gateway] PULL_DATA -> TTS")
        forward_to_tts(data)
    elif msg_type == 0x03:
        print("[Gateway] PULL_RESP (Join Accept) -> Device")
        forward_to_device(data)
    elif msg_type == 0x01:
        print("[Gateway] PUSH_ACK")
    else:
        print("[Gateway] Unknown type:", msg_type)
